<?= $this->extend('Layout/Starter') ?>

<?= $this->section('css') ?>
<style>
    body {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        min-height: 100vh;
        font-family: 'Poppins', sans-serif;
    }
    
    .login-container {
        min-height: 100vh;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 20px;
    }
    
    .login-card {
        background: white;
        border-radius: 20px;
        box-shadow: 0 20px 40px rgba(0,0,0,0.1);
        overflow: hidden;
        width: 100%;
        max-width: 400px;
    }
    
    .login-header {
        background: linear-gradient(135deg, #8B5CF6 0%, #7C3AED 100%);
        padding: 40px 30px;
        text-align: center;
        color: white;
    }
    
    .crown-icon {
        font-size: 3rem;
        margin-bottom: 15px;
        display: block;
    }
    
    .login-title {
        font-size: 1.8rem;
        font-weight: 700;
        margin-bottom: 8px;
    }
    
    .login-subtitle {
        font-size: 0.9rem;
        opacity: 0.9;
    }
    
    .login-body {
        padding: 40px 30px;
    }
    
    .form-group {
        margin-bottom: 25px;
        position: relative;
    }
    
    .form-input {
        width: 100%;
        padding: 15px 20px 15px 50px;
        border: 2px solid #E5E7EB;
        border-radius: 12px;
        font-size: 1rem;
        transition: all 0.3s ease;
        background: #F9FAFB;
    }
    
    .form-input:focus {
        outline: none;
        border-color: #8B5CF6;
        background: white;
        box-shadow: 0 0 0 3px rgba(139, 92, 246, 0.1);
    }
    
    .input-icon {
        position: absolute;
        left: 18px;
        top: 50%;
        transform: translateY(-50%);
        color: #9CA3AF;
        font-size: 1.1rem;
    }
    
    .password-toggle {
        position: absolute;
        right: 18px;
        top: 50%;
        transform: translateY(-50%);
        background: none;
        border: none;
        color: #9CA3AF;
        cursor: pointer;
        font-size: 1.1rem;
    }
    
    .login-btn {
        width: 100%;
        background: linear-gradient(135deg, #8B5CF6 0%, #7C3AED 100%);
        color: white;
        border: none;
        padding: 15px;
        border-radius: 12px;
        font-size: 1rem;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.3s ease;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
    }
    
    .login-btn:hover {
        transform: translateY(-2px);
        box-shadow: 0 10px 20px rgba(139, 92, 246, 0.3);
    }
    
    .register-link {
        text-align: center;
        margin-top: 25px;
        color: #6B7280;
        font-size: 0.9rem;
    }
    
    .register-link a {
        color: #8B5CF6;
        text-decoration: none;
        font-weight: 600;
    }
    
    .register-link a:hover {
        text-decoration: underline;
    }
    
    .demo-credentials {
        background: #F3F4F6;
        border-radius: 12px;
        padding: 15px;
        margin-top: 20px;
        display: flex;
        align-items: center;
        gap: 10px;
        font-size: 0.85rem;
        color: #6B7280;
    }
    
    .demo-credentials i {
        color: #8B5CF6;
        font-size: 1.1rem;
    }
    
    .dark-mode-toggle {
        position: fixed;
        top: 20px;
        right: 20px;
        background: rgba(255, 255, 255, 0.2);
        border: none;
        border-radius: 12px;
        width: 50px;
        height: 50px;
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        font-size: 1.2rem;
        cursor: pointer;
        transition: all 0.3s ease;
        backdrop-filter: blur(10px);
    }
    
    .dark-mode-toggle:hover {
        background: rgba(255, 255, 255, 0.3);
        transform: scale(1.05);
    }
    
    .error-message {
        color: #EF4444;
        font-size: 0.85rem;
        margin-top: 5px;
        display: block;
    }
    
    /* Dark mode styles */
    body.dark-mode {
        background: linear-gradient(135deg, #1F2937 0%, #111827 100%);
    }
    
    body.dark-mode .login-card {
        background: #1F2937;
        color: white;
    }
    
    body.dark-mode .form-input {
        background: #374151;
        border-color: #4B5563;
        color: white;
    }
    
    body.dark-mode .form-input:focus {
        background: #4B5563;
        border-color: #8B5CF6;
    }
    
    body.dark-mode .demo-credentials {
        background: #374151;
        color: #D1D5DB;
    }
    
    @media (max-width: 480px) {
        .login-container {
            padding: 10px;
        }
        
        .login-header {
            padding: 30px 20px;
        }
        
        .login-body {
            padding: 30px 20px;
        }
        
        .crown-icon {
            font-size: 2.5rem;
        }
        
        .login-title {
            font-size: 1.5rem;
        }
    }
</style>
<?= $this->endSection() ?>

<?= $this->section('content') ?>

<div class="login-container">
    <!-- Dark Mode Toggle -->
    <button class="dark-mode-toggle" onclick="toggleDarkMode()">
        <i class="bi bi-moon-fill"></i>
    </button>
    
    <div class="login-card">
        <!-- Header Section -->
        <div class="login-header">
            <i class="bi bi-crown-fill crown-icon"></i>
            <h1 class="login-title">Prince Panel</h1>
            <p class="login-subtitle">Welcome back! Sign in to your account</p>
        </div>
        
        <!-- Form Section -->
        <div class="login-body">
            <?= $this->include('Layout/msgStatus') ?>
            
            <?= form_open() ?>
            
            <!-- Username Field -->
            <div class="form-group">
                <i class="bi bi-person-fill input-icon"></i>
                <input type="text" class="form-input" name="username" id="username" placeholder="princeaalyan" value="princeaalyan" required minlength="4">
                <?php if ($validation->hasError('username')) : ?>
                    <span class="error-message"><?= $validation->getError('username') ?></span>
                <?php endif; ?>
            </div>
            
            <!-- Password Field -->
            <div class="form-group">
                <i class="bi bi-lock-fill input-icon"></i>
                <input type="password" class="form-input" name="password" id="password" placeholder="••••••••" required minlength="6">
                <button type="button" class="password-toggle" onclick="togglePassword()">
                    <i class="bi bi-eye-fill" id="passwordToggleIcon"></i>
                </button>
                <?php if ($validation->hasError('password')) : ?>
                    <span class="error-message"><?= $validation->getError('password') ?></span>
                <?php endif; ?>
            </div>
            
            <!-- Hidden IP Field -->
            <input type="hidden" name="ip" value="<?php echo $_SERVER['HTTP_USER_AGENT']; ?>" required>
            <?php if ($validation->hasError('ip')) : ?>
                <span class="error-message"><?= $validation->getError('ip') ?></span>
            <?php endif; ?>
            
            <!-- Sign In Button -->
            <button type="submit" class="login-btn">
                <span>Sign In</span>
                <i class="bi bi-arrow-right"></i>
            </button>
            
            <?= form_close() ?>
            
            <!-- Register Link -->
            <div class="register-link">
                Don't have an account? <a href="<?= site_url('register') ?>">Create one here</a>
            </div>
            
            <!-- Demo Credentials -->
            <div class="demo-credentials">
                <i class="bi bi-info-circle-fill"></i>
                <span>Demo Admin: admin / admin123</span>
            </div>
        </div>
    </div>
</div>

<?= $this->endSection() ?>

<?= $this->section('js') ?>
<script>
    function togglePassword() {
        const passwordInput = document.getElementById('password');
        const toggleIcon = document.getElementById('passwordToggleIcon');
        
        if (passwordInput.type === 'password') {
            passwordInput.type = 'text';
            toggleIcon.className = 'bi bi-eye-slash-fill';
        } else {
            passwordInput.type = 'password';
            toggleIcon.className = 'bi bi-eye-fill';
        }
    }
    
    function toggleDarkMode() {
        document.body.classList.toggle('dark-mode');
        const toggleBtn = document.querySelector('.dark-mode-toggle i');
        
        if (document.body.classList.contains('dark-mode')) {
            toggleBtn.className = 'bi bi-sun-fill';
            localStorage.setItem('darkMode', 'enabled');
        } else {
            toggleBtn.className = 'bi bi-moon-fill';
            localStorage.setItem('darkMode', 'disabled');
        }
    }
    
    // Check for saved dark mode preference
    if (localStorage.getItem('darkMode') === 'enabled') {
        document.body.classList.add('dark-mode');
        document.querySelector('.dark-mode-toggle i').className = 'bi bi-sun-fill';
    }
</script>
<?= $this->endSection() ?>