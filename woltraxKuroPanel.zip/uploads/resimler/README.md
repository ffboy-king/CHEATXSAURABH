# Resim Dosyaları

Bu dizine aşağıdaki resim dosyalarını yerleştirin:

## Gerekli Dosyalar:

### 1. `arkaplan.jpg`
- **Kullanım:** Sistem genelinde arka plan resmi
- **Konum:** `/uploads/resimler/arkaplan.jpg`
- **Özellikler:** 
  - Karanlık tema için uygun
  - Yüksek çözünürlük (1920x1080+)
  - JPG formatında

### 2. `resim.jpg`
- **Kullanım:** Login/Register panelinin sol tarafındaki resim
- **Konum:** `/uploads/resimler/resim.jpg`
- **Özellikler:**
  - Anime karakteri veya uygun görsel
  - Kırmızı panel üzerinde görünecek
  - JPG formatında

## Kurulum Adımları:

1. Bu README dosyasını silin
2. `arkaplan.jpg` dosyasını bu dizine koyun
3. `resim.jpg` dosyasını bu dizine koyun
4. Dosya isimlerinin tam olarak yukarıdaki gibi olduğundan emin olun

## Not:
- Dosyalar JPG formatında olmalı
- Dosya boyutları 2MB'den küçük olmalı
- Dosya isimleri küçük harfle yazılmalı 