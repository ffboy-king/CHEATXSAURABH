<?php

include('conn.php');
include('mail.php');

// For Credits
$sql = "SELECT * FROM credit where id=1";
$result = mysqli_query($conn, $sql);
$credit = mysqli_fetch_assoc($result);

?>

<?= $this->extend('Layout/Starter') ?>
<?= $this->section('content') ?>

<style>
* {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
}

body {
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
}

.prince-register-container {
    min-height: 100vh;
    background: #f8f9fa;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 20px;
    position: relative;
}

.prince-register-card {
    background: white;
    border-radius: 16px;
    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.08);
    overflow: hidden;
    width: 420px;
    max-width: 100%;
}

.prince-header {
    background: linear-gradient(135deg, #8b5cf6 0%, #a855f7 100%);
    color: white;
    padding: 32px 24px;
    text-align: center;
    position: relative;
}

.prince-crown {
    width: 48px;
    height: 48px;
    margin: 0 auto 16px;
    background: white;
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 24px;
}

.prince-title {
    font-size: 24px;
    font-weight: 600;
    margin-bottom: 4px;
    letter-spacing: -0.02em;
}

.prince-subtitle {
    font-size: 14px;
    opacity: 0.9;
    font-weight: 400;
}

.prince-form {
    padding: 32px 24px;
}

.prince-input-group {
    position: relative;
    margin-bottom: 16px;
}

.prince-input {
    width: 100%;
    padding: 12px 16px 12px 40px;
    border: 1px solid #e2e8f0;
    border-radius: 8px;
    font-size: 14px;
    background: #f1f5f9;
    color: #334155;
    transition: all 0.2s ease;
}

.prince-input:focus {
    outline: none;
    border-color: #8b5cf6;
    background: white;
    box-shadow: 0 0 0 3px rgba(139, 92, 246, 0.1);
}

.prince-input::placeholder {
    color: #94a3b8;
}

.prince-input-icon {
    position: absolute;
    left: 12px;
    top: 50%;
    transform: translateY(-50%);
    color: #64748b;
    font-size: 16px;
    width: 16px;
    height: 16px;
    display: flex;
    align-items: center;
    justify-content: center;
}

.prince-password-toggle {
    position: absolute;
    right: 12px;
    top: 50%;
    transform: translateY(-50%);
    color: #94a3b8;
    cursor: pointer;
    font-size: 16px;
    width: 20px;
    height: 20px;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: color 0.2s ease;
}

.prince-password-toggle:hover {
    color: #64748b;
}

.prince-btn {
    width: 100%;
    background: linear-gradient(135deg, #8b5cf6 0%, #a855f7 100%);
    color: white;
    border: none;
    padding: 12px 16px;
    border-radius: 8px;
    font-size: 14px;
    font-weight: 500;
    cursor: pointer;
    transition: all 0.2s ease;
    margin: 24px 0 16px 0;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
}

.prince-btn:hover {
    transform: translateY(-1px);
    box-shadow: 0 4px 12px rgba(139, 92, 246, 0.4);
}

.prince-login-link {
    text-align: center;
    color: #64748b;
    font-size: 14px;
    padding: 16px 0;
    border-top: 1px solid #f1f5f9;
}

.prince-login-link a {
    color: #8b5cf6;
    text-decoration: none;
    font-weight: 500;
}

.prince-login-link a:hover {
    text-decoration: underline;
}

.error-message {
    color: #ef4444;
    font-size: 12px;
    margin-top: 4px;
    margin-left: 40px;
}

.dark-mode-toggle {
    position: absolute;
    top: 20px;
    right: 20px;
    background: rgba(255, 255, 255, 0.9);
    border: none;
    color: #64748b;
    padding: 8px;
    border-radius: 50%;
    cursor: pointer;
    font-size: 16px;
    width: 36px;
    height: 36px;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: all 0.2s ease;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}

.dark-mode-toggle:hover {
    background: white;
    color: #475569;
}

.prince-input.readonly {
    background: #f1f5f9;
    color: #64748b;
    cursor: not-allowed;
}

@media (max-width: 768px) {
    .prince-register-container {
        padding: 16px;
    }
    
    .prince-register-card {
        width: 100%;
        max-width: 400px;
    }
    
    .prince-header {
        padding: 24px 20px;
    }
    
    .prince-form {
        padding: 24px 20px;
    }
}
</style>

<div class="prince-register-container">
    <button class="dark-mode-toggle" onclick="toggleDarkMode()">
        🌙
    </button>
    
    <div class="prince-register-card">
        <div class="prince-header">
            <div class="prince-crown">👑</div>
            <h1 class="prince-title">Prince Panel</h1>
            <p class="prince-subtitle">Create your account to get started</p>
        </div>
        
        <div class="prince-form">
            <?= $this->include('Layout/msgStatus') ?>
            
            <?= form_open() ?>
            
            <div class="prince-input-group">
                <div class="prince-input-icon">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M20 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z"/>
                    </svg>
                </div>
                <input type="email" class="prince-input" name="email" id="email" 
                       placeholder="Enter Your Email" minlength="13" maxlength="40" 
                       value="<?= old('email') ?>" required>
                <?php if ($validation->hasError('email')) : ?>
                    <div class="error-message"><?= $validation->getError('email') ?></div>
                <?php endif; ?>
            </div>
            
            <div class="prince-input-group">
                <div class="prince-input-icon">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/>
                    </svg>
                </div>
                <input type="text" class="prince-input" name="username" id="username" 
                       placeholder="Username" minlength="4" maxlength="24" 
                       value="<?= old('username') ?>" required>
                <?php if ($validation->hasError('username')) : ?>
                    <div class="error-message"><?= $validation->getError('username') ?></div>
                <?php endif; ?>
            </div>
            
            <div class="prince-input-group">
                <div class="prince-input-icon">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M12 2C13.1 2 14 2.9 14 4C14 5.1 13.1 6 12 6C10.9 6 10 5.1 10 4C10 2.9 10.9 2 12 2ZM21 9V7L15 1L13.5 2.5L16.17 5.17L10.5 10.84L10.84 11.17L15.17 6.84L19.84 11.5L21 9.17L21 9ZM1 21V19L7 13L9.5 15.5L3.5 21.5L1 21Z"/>
                    </svg>
                </div>
                <input type="text" class="prince-input" name="fullname" id="fullname" 
                       placeholder="Full Name" minlength="4" maxlength="24" 
                       value="<?= old('fullname') ?>" required>
                <?php if ($validation->hasError('fullname')) : ?>
                    <div class="error-message"><?= $validation->getError('fullname') ?></div>
                <?php endif; ?>
            </div>
            
            <div class="prince-input-group">
                <div class="prince-input-icon">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M18,8h-1V6c0-2.76-2.24-5-5-5S7,3.24,7,6v2H6c-1.1,0-2,0.9-2,2v10c0,1.1,0.9,2,2,2h12c1.1,0,2-0.9,2-2V10C20,8.9,19.1,8,18,8z M12,17c-1.1,0-2-0.9-2-2s0.9-2,2-2s2,0.9,2,2S13.1,17,12,17z M15.1,8H8.9V6c0-1.71,1.39-3.1,3.1-3.1s3.1,1.39,3.1,3.1V8z"/>
                    </svg>
                </div>
                <input type="password" class="prince-input" name="password" id="password" 
                       placeholder="Password" minlength="6" maxlength="24" required>
                <div class="prince-password-toggle" onclick="togglePassword('password')">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M12,9A3,3 0 0,0 9,12A3,3 0 0,0 12,15A3,3 0 0,0 15,12A3,3 0 0,0 12,9M12,17A5,5 0 0,1 7,12A5,5 0 0,1 12,7A5,5 0 0,1 17,12A5,5 0 0,1 12,17M12,4.5C7,4.5 2.73,7.61 1,12C2.73,16.39 7,19.5 12,19.5C17,19.5 21.27,16.39 23,12C21.27,7.61 17,4.5 12,4.5Z"/>
                    </svg>
                </div>
                <?php if ($validation->hasError('password')) : ?>
                    <div class="error-message"><?= $validation->getError('password') ?></div>
                <?php endif; ?>
            </div>
            
            <div class="prince-input-group">
                <div class="prince-input-icon">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M18,8h-1V6c0-2.76-2.24-5-5-5S7,3.24,7,6v2H6c-1.1,0-2,0.9-2,2v10c0,1.1,0.9,2,2,2h12c1.1,0,2-0.9,2-2V10C20,8.9,19.1,8,18,8z M12,17c-1.1,0-2-0.9-2-2s0.9-2,2-2s2,0.9,2,2S13.1,17,12,17z M15.1,8H8.9V6c0-1.71,1.39-3.1,3.1-3.1s3.1,1.39,3.1,3.1V8z"/>
                    </svg>
                </div>
                <input type="password" class="prince-input" name="password2" id="password2" 
                       placeholder="Confirm Password" minlength="6" maxlength="24" required>
                <div class="prince-password-toggle" onclick="togglePassword('password2')">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M12,9A3,3 0 0,0 9,12A3,3 0 0,0 12,15A3,3 0 0,0 15,12A3,3 0 0,0 12,9M12,17A5,5 0 0,1 7,12A5,5 0 0,1 12,7A5,5 0 0,1 17,12A5,5 0 0,1 12,17M12,4.5C7,4.5 2.73,7.61 1,12C2.73,16.39 7,19.5 12,19.5C17,19.5 21.27,16.39 23,12C21.27,7.61 17,4.5 12,4.5Z"/>
                    </svg>
                </div>
                <?php if ($validation->hasError('password2')) : ?>
                    <div class="error-message"><?= $validation->getError('password2') ?></div>
                <?php endif; ?>
            </div>
            
            <div class="prince-input-group">
                <div class="prince-input-icon">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M12,2A3,3 0 0,1 15,5V7H19A1,1 0 0,1 20,8V20A1,1 0 0,1 19,21H5A1,1 0 0,1 4,20V8A1,1 0 0,1 5,7H9V5A3,3 0 0,1 12,2M12,4A1,1 0 0,0 11,5V7H13V5A1,1 0 0,0 12,4Z"/>
                    </svg>
                </div>
                <input type="text" class="prince-input" name="referral" id="referral" 
                       placeholder="Referral Code" value="<?= old('referral') ?>" 
                       maxlength="25" required>
                <?php if ($validation->hasError('referral')) : ?>
                    <div class="error-message"><?= $validation->getError('referral') ?></div>
                <?php endif; ?>
            </div>
            
            <div class="prince-input-group">
                <div class="prince-input-icon">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M12,2A10,10 0 0,1 22,12A10,10 0 0,1 12,22A10,10 0 0,1 2,12A10,10 0 0,1 12,2M12,4A8,8 0 0,0 4,12A8,8 0 0,0 12,20A8,8 0 0,0 20,12A8,8 0 0,0 12,4M12,6A6,6 0 0,1 18,12A6,6 0 0,1 12,18A6,6 0 0,1 6,12A6,6 0 0,1 12,6M12,8A4,4 0 0,0 8,12A4,4 0 0,0 12,16A4,4 0 0,0 16,12A4,4 0 0,0 12,8Z"/>
                    </svg>
                </div>
                <input type="text" class="prince-input readonly" id="ip" 
                       placeholder="<?php echo $user_ip ?>" readonly>
            </div>
            
            <button type="submit" class="prince-btn" onclick="popup()">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M9,12l2,2l4-4m6,2A10,10 0 0,1 12,22A10,10 0 0,1 2,12A10,10 0 0,1 12,2A10,10 0 0,1 22,12Z"/>
                </svg>
                Register
            </button>
            
            <?= form_close() ?>
            
            <div class="prince-login-link">
                Already have an account? <a href="<?= site_url('login') ?>">Login here</a>
            </div>
        </div>
    </div>
</div>

<script>
function togglePassword(fieldId) {
    const passwordInput = document.getElementById(fieldId);
    const toggleIcon = passwordInput.parentElement.querySelector('.prince-password-toggle svg');
    
    if (passwordInput.type === 'password') {
        passwordInput.type = 'text';
        toggleIcon.innerHTML = '<path d="M11.83,9L15,12.16C15,12.11 15,12.05 15,12A3,3 0 0,0 12,9C11.94,9 11.89,9 11.83,9M7.53,9.8L9.08,11.35C9.03,11.56 9,11.77 9,12A3,3 0 0,0 12,15C12.22,15 12.44,14.97 12.65,14.92L14.2,16.47C13.53,16.8 12.79,17 12,17A5,5 0 0,1 7,12C7,11.21 7.2,10.47 7.53,9.8M2,4.27L4.28,6.55L4.73,7C3.08,8.3 1.78,10 1,12C2.73,16.39 7,19.5 12,19.5C13.55,19.5 15.03,19.2 16.38,18.66L16.81,19.09L19.73,22L21,20.73L3.27,3M12,7A5,5 0 0,1 17,12C17,12.64 16.87,13.26 16.64,13.82L19.57,16.75C21.07,15.5 22.27,13.86 23,12C21.27,7.61 17,4.5 12,4.5C10.6,4.5 9.26,4.75 8,5.2L10.17,7.35C10.76,7.13 11.37,7 12,7Z"/>';
    } else {
        passwordInput.type = 'password';
        toggleIcon.innerHTML = '<path d="M12,9A3,3 0 0,0 9,12A3,3 0 0,0 12,15A3,3 0 0,0 15,12A3,3 0 0,0 12,9M12,17A5,5 0 0,1 7,12A5,5 0 0,1 12,7A5,5 0 0,1 17,12A5,5 0 0,1 12,17M12,4.5C7,4.5 2.73,7.61 1,12C2.73,16.39 7,19.5 12,19.5C17,19.5 21.27,16.39 23,12C21.27,7.61 17,4.5 12,4.5Z"/>';
    }
}

function toggleDarkMode() {
    const container = document.querySelector('.prince-register-container');
    const card = document.querySelector('.prince-register-card');
    const toggle = document.querySelector('.dark-mode-toggle');
    
    if (container.style.background === 'rgb(31, 41, 55)') {
        container.style.background = '#f8f9fa';
        card.style.background = 'white';
        card.style.color = '#1e293b';
        toggle.textContent = '🌙';
        toggle.style.background = 'rgba(255, 255, 255, 0.9)';
        toggle.style.color = '#64748b';
    } else {
        container.style.background = '#1f2937';
        card.style.background = '#374151';
        card.style.color = 'white';
        toggle.textContent = '☀️';
        toggle.style.background = 'rgba(0, 0, 0, 0.2)';
        toggle.style.color = '#f1f5f9';
    }
}
</script>

<?= $this->endSection() ?>