from google.protobuf import descriptor as _descriptor
from google.protobuf import descriptor_pool as _descriptor_pool
from google.protobuf import runtime_version as _runtime_version
from google.protobuf import symbol_database as _symbol_database
from google.protobuf.internal import builder as _builder

DESCRIPTOR = _descriptor_pool.Default().AddSerializedFile(b'\n\ndata.proto\x12\x05proto\"\xfd\x04\n\x17\x41\x63\x63ountPersonalShowInfo\x12+\n\nbasic_info\x18\x01 \x01(\x0b\x32\x17.proto.AccountInfoBasic\x12*\n\x0cprofile_info\x18\x02 \x01(\x0b\x32\x14.proto.AvatarProfile\x12\x1f\n\x17ranking_leaderboard_pos\x18\x03 \x01(\x05\x12\x1d\n\x04news\x18\x04 \x03(\x0b\x32\x0f.proto.NewsItem\x12-\n\x0fhistory_ep_info\x18\x05 \x03(\x0b\x32\x14.proto.HistoryEpInfo\x12-\n\x0f\x63lan_basic_info\x18\x06 \x01(\x0b\x32\x14.proto.ClanInfoBasic\x12\x33\n\x12\x63\x61ptain_basic_info\x18\x07 \x01(\x0b\x32\x17.proto.AccountInfoBasic\x12 \n\x08pet_info\x18\x08 \x01(\x0b\x32\x0e.proto.PetInfo\x12+\n\x0bsocial_info\x18\t \x01(\x0b\x32\x16.proto.SocialBasicInfo\x12/\n\x10\x64iamond_cost_res\x18\n \x01(\x0b\x32\x15.proto.DiamondCostRes\x12\x31\n\x11\x63redit_score_info\x18\x0b \x01(\x0b\x32\x16.proto.CreditScoreInfo\x12\x33\n\x12pre_veteran_action\x18\x0c \x01(\x0b\x32\x17.proto.PreVeteranAction\x12\x39\n\x15\x65quipped_achievements\x18\r \x03(\x0b\x32\x1a.proto.EquippedAchievement\x12\x13\n\x0bmmr_ratings\x18\x0e \x03(\x05\"\xf5\x06\n\x10\x41\x63\x63ountInfoBasic\x12\x12\n\naccount_id\x18\x01 \x01(\x04\x12\x14\n\x0c\x61\x63\x63ount_type\x18\x02 \x01(\r\x12\x10\n\x08nickname\x18\x03 \x01(\t\x12\x0e\n\x06region\x18\x05 \x01(\t\x12\r\n\x05level\x18\x06 \x01(\r\x12\x0b\n\x03\x65xp\x18\x07 \x01(\r\x12\x11\n\tbanner_id\x18\x0b \x01(\r\x12\x10\n\x08head_pic\x18\x0c \x01(\r\x12\x0c\n\x04rank\x18\x0e \x01(\r\x12\x16\n\x0eranking_points\x18\x0f \x01(\r\x12\x16\n\x0ehas_elite_pass\x18\x11 \x01(\x08\x12\x11\n\tbadge_cnt\x18\x12 \x01(\r\x12\x10\n\x08\x62\x61\x64ge_id\x18\x13 \x01(\r\x12\x11\n\tseason_id\x18\x14 \x01(\r\x12\r\n\x05liked\x18\x15 \x01(\r\x12\x11\n\tshow_rank\x18\x17 \x01(\x08\x12\x15\n\rlast_login_at\x18\x18 \x01(\x03\x12\x0f\n\x07\x63s_rank\x18\x1e \x01(\r\x12\x19\n\x11\x63s_ranking_points\x18\x1f \x01(\r\x12\x19\n\x11weapon_skin_shows\x18  \x03(\r\x12\x10\n\x08max_rank\x18# \x01(\r\x12\x13\n\x0b\x63s_max_rank\x18$ \x01(\r\x12\x15\n\rpeak_rank_pos\x18\' \x01(\r\x12.\n\x0f\x61\x63\x63ount_prefers\x18) \x01(\x0b\x32\x15.proto.AccountPrefers\x12\x11\n\tcreate_at\x18, \x01(\x03\x12\r\n\x05title\x18\x30 \x01(\r\x12\x33\n\x12\x65xternal_icon_info\x18\x31 \x01(\x0b\x32\x17.proto.ExternalIconInfo\x12\x17\n\x0frelease_version\x18\x32 \x01(\t\x12\x14\n\x0cshow_br_rank\x18\x34 \x01(\x08\x12\x14\n\x0cshow_cs_rank\x18\x35 \x01(\x08\x12\x32\n\x11social_highlights\x18= \x01(\x0b\x32\x17.proto.SocialHighlights\x12\x15\n\ritem_tag_info\x18? \x01(\x0c\x12\x12\n\nhippo_rank\x18\x42 \x01(\r\x12\x1c\n\x14hippo_ranking_points\x18\x43 \x01(\r\x12+\n\x0f\x63s_rank_entries\x18\x41 \x03(\x0b\x32\x12.proto.CsRankEntry\x12\x19\n\x0craw_field_60\x18< \x01(\rH\x00\x88\x01\x01\x42\x0f\n\r_raw_field_60\":\n\x10SocialHighlights\x12&\n\x07\x65ntries\x18\x01 \x03(\x0b\x32\x15.proto.HighlightEntry\"a\n\x0eHighlightEntry\x12\x11\n\tseason_id\x18\x01 \x01(\r\x12\x16\n\x0ehighlight_type\x18\x02 \x01(\r\x12$\n\x05stats\x18\x03 \x01(\x0b\x32\x15.proto.HighlightStats\"x\n\x0eHighlightStats\x12\x0c\n\x04mode\x18\x01 \x01(\r\x12\x16\n\x0ematches_played\x18\x02 \x01(\r\x12\x13\n\x0bmatches_won\x18\x03 \x01(\r\x12\x16\n\x0etop_percentage\x18\x04 \x01(\r\x12\x13\n\x0bseason_rank\x18\x05 \x01(\r\"E\n\x0b\x43sRankEntry\x12\x0f\n\x07mode_id\x18\x01 \x01(\r\x12\x0e\n\x06points\x18\x02 \x01(\r\x12\x15\n\runlock_status\x18\x03 \x01(\r\"\xb3\x01\n\x0e\x41\x63\x63ountPrefers\x12\x17\n\x0f\x62r_pregame_show\x18\x01 \x01(\r\x12\x16\n\x0ehide_clan_info\x18\x04 \x01(\x08\x12\x19\n\x11hide_weapon_skins\x18\x05 \x01(\x08\x12\x17\n\x0fshow_elite_pass\x18\x07 \x01(\x08\x12\x12\n\nshow_title\x18\x08 \x01(\x08\x12\x18\n\x0braw_field_3\x18\x03 \x01(\rH\x00\x88\x01\x01\x42\x0e\n\x0c_raw_field_3\"\xdc\x01\n\rAvatarProfile\x12\x11\n\tavatar_id\x18\x01 \x01(\r\x12\x16\n\x0e\x63osmetic_items\x18\x03 \x03(\r\x12\x17\n\x0f\x65quipped_skills\x18\x04 \x03(\r\x12\x1a\n\x12pve_primary_weapon\x18\x06 \x01(\r\x12%\n\x0bskill_slots\x18\x05 \x03(\x0b\x32\x10.proto.SkillSlot\x12\x18\n\x10skin_unlock_time\x18\x08 \x01(\r\x12\x19\n\x0craw_field_12\x18\x0c \x01(\rH\x00\x88\x01\x01\x42\x0f\n\r_raw_field_12\"1\n\tSkillSlot\x12\x12\n\nslot_index\x18\x01 \x01(\r\x12\x10\n\x08skill_id\x18\x02 \x01(\r\"\x89\x01\n\rClanInfoBasic\x12\x0f\n\x07\x63lan_id\x18\x01 \x01(\x04\x12\x11\n\tclan_name\x18\x02 \x01(\t\x12\x12\n\ncaptain_id\x18\x03 \x01(\x04\x12\x12\n\nclan_level\x18\x04 \x01(\r\x12\x13\n\x0bmax_members\x18\x05 \x01(\r\x12\x17\n\x0f\x63urrent_members\x18\x06 \x01(\r\"\x88\x01\n\x07PetInfo\x12\x0e\n\x06pet_id\x18\x01 \x01(\r\x12\x10\n\x08pet_name\x18\x02 \x01(\t\x12\r\n\x05level\x18\x03 \x01(\r\x12\x0b\n\x03\x65xp\x18\x04 \x01(\r\x12\x13\n\x0bis_selected\x18\x05 \x01(\x08\x12\x0f\n\x07skin_id\x18\x06 \x01(\r\x12\x19\n\x11selected_skill_id\x18\t \x01(\r\"\xd4\x01\n\x0fSocialBasicInfo\x12\x12\n\naccount_id\x18\x01 \x01(\x04\x12\x1d\n\x06gender\x18\x02 \x01(\x0e\x32\r.proto.Gender\x12!\n\x08language\x18\x03 \x01(\x0e\x32\x0f.proto.Language\x12\x18\n\x10social_highlight\x18\t \x01(\t\x12\'\n\x07privacy\x18\n \x01(\x0e\x32\x16.proto.PrivacySettings\x12(\n\x0cregion_stats\x18\x0e \x03(\x0b\x32\x12.proto.RegionStats\"\x92\x01\n\x0bRegionStats\x12\x13\n\x0bregion_code\x18\x01 \x01(\x0c\x12\x15\n\rtotal_matches\x18\x02 \x01(\r\x12\x0c\n\x04wins\x18\x03 \x01(\r\x12\x14\n\x0chighest_rank\x18\x04 \x01(\r\x12\x1a\n\x12last_season_played\x18\x05 \x01(\r\x12\x17\n\x0flast_match_time\x18\x06 \x01(\x03\"\\\n\x0f\x43reditScoreInfo\x12\r\n\x05score\x18\x01 \x01(\r\x12\x0e\n\x06status\x18\x03 \x01(\r\x12\r\n\x05start\x18\x08 \x01(\x03\x12\x0b\n\x03\x65nd\x18\t \x01(\x03\x12\x0e\n\x06reason\x18\n \x01(\r\"\x89\x01\n\x10\x45xternalIconInfo\x12!\n\x06status\x18\x01 \x01(\x0e\x32\x11.proto.IconStatus\x12(\n\tshow_type\x18\x02 \x01(\x0e\x32\x15.proto.IconVisibility\x12\x18\n\x0braw_field_3\x18\x03 \x01(\rH\x00\x88\x01\x01\x42\x0e\n\x0c_raw_field_3\"\x85\x02\n\x08NewsItem\x12\x0f\n\x07news_id\x18\x01 \x01(\x05\x12\x14\n\x0c\x63ontent_data\x18\x02 \x01(\x0c\x12\x11\n\tnews_type\x18\x03 \x01(\x05\x12\x10\n\x08priority\x18\x04 \x01(\x05\x12\x14\n\x0cpublish_time\x18\x05 \x01(\x03\x12\x13\n\x0b\x65xpire_time\x18\x06 \x01(\x03\x12-\n\nextra_info\x18\x07 \x01(\x0b\x32\x19.proto.NewsItem.NewsExtra\x1aS\n\tNewsExtra\x12\x17\n\x0fsource_platform\x18\x01 \x01(\x05\x12\x19\n\x11localization_data\x18\x02 \x01(\x0c\x12\x12\n\nimage_data\x18\x03 \x01(\x0c\"\xe4\x01\n\rHistoryEpInfo\x12\x11\n\tseason_id\x18\x01 \x01(\x05\x12\x12\n\nepisode_id\x18\x02 \x01(\x05\x12\x30\n\x05stats\x18\x03 \x01(\x0b\x32!.proto.HistoryEpInfo.EpisodeStats\x1az\n\x0c\x45pisodeStats\x12\x16\n\x0ematches_played\x18\x01 \x01(\x05\x12\x16\n\x0etop_placements\x18\x02 \x01(\x05\x12\r\n\x05kills\x18\x03 \x01(\x05\x12\x14\n\x0c\x64\x61mage_dealt\x18\x04 \x01(\x05\x12\x15\n\rsurvival_time\x18\x05 \x01(\x05\"W\n\x0e\x44iamondCostRes\x12\x14\n\x0c\x64iamond_cost\x18\x01 \x01(\r\x12\x15\n\rcurrency_type\x18\x02 \x01(\r\x12\x18\n\x10\x64iscount_percent\x18\x03 \x01(\r\"C\n\x10PreVeteranAction\x12\x13\n\x0b\x61\x63tion_type\x18\x01 \x01(\r\x12\x1a\n\x12\x61\x63tion_expire_time\x18\x02 \x01(\x03\"\\\n\x13\x45quippedAchievement\x12\x16\n\x0e\x61\x63hievement_id\x18\x01 \x01(\r\x12\x16\n\x0eprogress_value\x18\x02 \x01(\r\x12\x15\n\runlock_status\x18\x03 \x01(\r*@\n\x06Gender\x12\x12\n\x0eGENDER_UNKNOWN\x10\x00\x12\x0f\n\x0bGENDER_MALE\x10\x02\x12\x11\n\rGENDER_FEMALE\x10\x01*O\n\x08Language\x12\x14\n\x10LANGUAGE_UNKNOWN\x10\x00\x12\x14\n\x10LANGUAGE_ENGLISH\x10\x01\x12\x17\n\x13LANGUAGE_PORTUGUESE\x10\x07*Q\n\x0fPrivacySettings\x12\x10\n\x0cPRIVACY_OPEN\x10\x00\x12\x18\n\x14PRIVACY_FRIENDS_ONLY\x10\x01\x12\x12\n\x0ePRIVACY_CLOSED\x10\x02*0\n\nIconStatus\x12\x11\n\rICON_INACTIVE\x10\x00\x12\x0f\n\x0bICON_ACTIVE\x10\x01*3\n\x0eIconVisibility\x12\x0f\n\x0bICON_HIDDEN\x10\x00\x12\x10\n\x0cICON_VISIBLE\x10\x01\x62\x06proto3')

_globals = globals()
_builder.BuildMessageAndEnumDescriptors(DESCRIPTOR, _globals)
_builder.BuildTopDescriptorsAndMessages(DESCRIPTOR, 'data_pb2', _globals)
if not _descriptor._USE_C_DESCRIPTORS:
  DESCRIPTOR._loaded_options = None
  _globals['_GENDER']._serialized_start=3981
  _globals['_GENDER']._serialized_end=4045
  _globals['_LANGUAGE']._serialized_start=4047
  _globals['_LANGUAGE']._serialized_end=4126
  _globals['_PRIVACYSETTINGS']._serialized_start=4128
  _globals['_PRIVACYSETTINGS']._serialized_end=4209
  _globals['_ICONSTATUS']._serialized_start=4211
  _globals['_ICONSTATUS']._serialized_end=4259
  _globals['_ICONVISIBILITY']._serialized_start=4261
  _globals['_ICONVISIBILITY']._serialized_end=4312
  _globals['_ACCOUNTPERSONALSHOWINFO']._serialized_start=22
  _globals['_ACCOUNTPERSONALSHOWINFO']._serialized_end=659
  _globals['_ACCOUNTINFOBASIC']._serialized_start=662
  _globals['_ACCOUNTINFOBASIC']._serialized_end=1547
  _globals['_SOCIALHIGHLIGHTS']._serialized_start=1549
  _globals['_SOCIALHIGHLIGHTS']._serialized_end=1607
  _globals['_HIGHLIGHTENTRY']._serialized_start=1609
  _globals['_HIGHLIGHTENTRY']._serialized_end=1706
  _globals['_HIGHLIGHTSTATS']._serialized_start=1708
  _globals['_HIGHLIGHTSTATS']._serialized_end=1828
  _globals['_CSRANKENTRY']._serialized_start=1830
  _globals['_CSRANKENTRY']._serialized_end=1899
  _globals['_ACCOUNTPREFERS']._serialized_start=1902
  _globals['_ACCOUNTPREFERS']._serialized_end=2081
  _globals['_AVATARPROFILE']._serialized_start=2084
  _globals['_AVATARPROFILE']._serialized_end=2304
  _globals['_SKILLSLOT']._serialized_start=2306
  _globals['_SKILLSLOT']._serialized_end=2355
  _globals['_CLANINFOBASIC']._serialized_start=2358
  _globals['_CLANINFOBASIC']._serialized_end=2495
  _globals['_PETINFO']._serialized_start=2498
  _globals['_PETINFO']._serialized_end=2634
  _globals['_SOCIALBASICINFO']._serialized_start=2637
  _globals['_SOCIALBASICINFO']._serialized_end=2849
  _globals['_REGIONSTATS']._serialized_start=2852
  _globals['_REGIONSTATS']._serialized_end=2998
  _globals['_CREDITSCOREINFO']._serialized_start=3000
  _globals['_CREDITSCOREINFO']._serialized_end=3092
  _globals['_EXTERNALICONINFO']._serialized_start=3095
  _globals['_EXTERNALICONINFO']._serialized_end=3232
  _globals['_NEWSITEM']._serialized_start=3235
  _globals['_NEWSITEM']._serialized_end=3496
  _globals['_NEWSITEM_NEWSEXTRA']._serialized_start=3413
  _globals['_NEWSITEM_NEWSEXTRA']._serialized_end=3496
  _globals['_HISTORYEPINFO']._serialized_start=3499
  _globals['_HISTORYEPINFO']._serialized_end=3727
  _globals['_HISTORYEPINFO_EPISODESTATS']._serialized_start=3605
  _globals['_HISTORYEPINFO_EPISODESTATS']._serialized_end=3727
  _globals['_DIAMONDCOSTRES']._serialized_start=3729
  _globals['_DIAMONDCOSTRES']._serialized_end=3816
  _globals['_PREVETERANACTION']._serialized_start=3818
  _globals['_PREVETERANACTION']._serialized_end=3885
  _globals['_EQUIPPEDACHIEVEMENT']._serialized_start=3887
  _globals['_EQUIPPEDACHIEVEMENT']._serialized_end=3979