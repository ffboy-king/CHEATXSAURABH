<?php
include 'config.php'; // Your DB connection
session_start();

// Only Allow Admin/Reseller/Owner
if (!in_array($_SESSION['role'], ['owner', 'admin', 'reseller'])) {
    die("Access Denied");
}

if (isset($_POST['generate'])) {
    $duration = intval($_POST['days']);
    $amount = intval($_POST['amount']);
    $generated_by = $_SESSION['user_id'];

    for ($i = 0; $i < $amount; $i++) {
        $key = "KURO-" . strtoupper(bin2hex(random_bytes(4))) . "-" . rand(1000,9999);
        // Expiry is NULL until first use, or set immediately if you prefer
        $sql = "INSERT INTO license_keys (key_code, generated_by, duration_days) VALUES ('$key', '$generated_by', '$duration')";
        mysqli_query($conn, $sql);
    }
    echo "Keys Generated Successfully!";
}
?>
