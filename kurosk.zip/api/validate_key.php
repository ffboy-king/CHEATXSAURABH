<?php
include 'config.php';
header('Content-Type: application/json');

// 1. C++ Code ke Parameters Receive Karna
// Aapka SRC 'user_key' aur 'serial' bhej raha hai
$user_key = isset($_POST['user_key']) ? mysqli_real_escape_string($conn, $_POST['user_key']) : '';
$serial   = isset($_POST['serial']) ? mysqli_real_escape_string($conn, $_POST['serial']) : '';
$game     = isset($_POST['game']) ? $_POST['game'] : 'PUBG'; // Default PUBG

// Agar key nahi bheji to error
if (empty($user_key) || empty($serial)) {
    die(json_encode(["status" => false, "reason" => "Invalid Request Data"]));
}

// 2. Database Check
$query = mysqli_query($conn, "SELECT * FROM license_keys WHERE key_code='$user_key'");
$data  = mysqli_fetch_assoc($query);

if (!$data) {
    die(json_encode(["status" => false, "reason" => "Key Not Found"]));
}

// 3. Status Check
if ($data['status'] == 'banned') {
    die(json_encode(["status" => false, "reason" => "Key is Banned"]));
}

// 4. Expiry & Activation Logic
$current_time = time();

// Agar key NEW hai, to abhi activate karo
if ($data['status'] == 'active' && $data['expires_at'] == NULL) {
    $duration_sec = $data['duration_days'] * 86400; // Days to Seconds
    $new_expiry = date('Y-m-d H:i:s', $current_time + $duration_sec);
    
    mysqli_query($conn, "UPDATE license_keys SET status='used', device_id='$serial', expires_at='$new_expiry' WHERE id={$data['id']}");
    $data['expires_at'] = $new_expiry; // Update variable for checking below
    $data['device_id'] = $serial;
}

// Device Lock Check (Serial Match)
if ($data['device_id'] != $serial) {
    die(json_encode(["status" => false, "reason" => "Device Mismatch! Reset Key."]));
}

// Time Check
if (strtotime($data['expires_at']) < $current_time) {
    mysqli_query($conn, "UPDATE license_keys SET status='expired' WHERE id={$data['id']}");
    die(json_encode(["status" => false, "reason" => "Key Expired"]));
}

// ======================================================
// 5. SECRET TOKEN GENERATION (C++ Code Ke Liye Zaroori)
// ======================================================

// Aapke C++ code mein ye Secret Key hardcoded hai:
// "Vm8Lk7Uj2JmsjCPVPVjrLa7zgfx3uz9E"
$secret_salt = "Vm8Lk7Uj2JmsjCPVPVjrLa7zgfx3uz9E";

// Logic: auth = "PUBG" + "-" + key + "-" + UUID + "-" + SALT
$auth_string = "PUBG" . "-" . $user_key . "-" . $serial . "-" . $secret_salt;

// MD5 Hash Generate karna (Jo C++ CalcMD5 function karega)
$token = md5($auth_string);
$rng   = time(); // Current Server Time

// 6. Final Response (Exactly jaisa C++ maang raha hai)
echo json_encode([
    "status" => true,
    "data" => [
        "token" => $token,
        "rng"   => $rng
    ]
]);

?>
