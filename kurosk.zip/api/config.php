<?php
// ==========================================
// INFINITYFREE DATABASE CONFIGURATION
// ==========================================

// STEP 1: InfinityFree ke "Control Panel" (VistaPanel) mein login karein.
// STEP 2: Right side mein "MySQL Databases" par click karein.
// STEP 3: Wahan se neeche di gayi details copy karke yahan paste karein.

$host   = "mysql-cheatxsaurabh.alwaysdata.net";  // Example: sql123.infinityfree.com (Ye 'localhost' NAHI hoga)
$user   = "444399_mod";              // Example: if0_12345678 (Aapka MySQL Username)
$pass   = "saurabh9057";       // Ye wahi password hai jo aap Client Area login ke liye use karte hain
$dbname = "cheatxsaurabh_mod";         // Example: if0_12345678_kuro (Pura naam jo panel me dikh raha hai)

// ==========================================
// DATABASE CONNECTION LOGIC
// ==========================================

$conn = mysqli_connect($host, $user, $pass, $dbname);

// Connection check karna
if (!$conn) {
    // Agar connection fail ho jaye to error dikhaye
    die("Database Connection Failed: " . mysqli_connect_error());
}

// Timezone set karna (India ke liye)
date_default_timezone_set('Asia/Kolkata');

?>
