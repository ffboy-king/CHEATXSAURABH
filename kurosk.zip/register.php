$ref_code = $_POST['referral_code'];
$check_ref = mysqli_query($conn, "SELECT * FROM referral_codes WHERE code='$ref_code' AND used_count < max_uses");

if (mysqli_num_rows($check_ref) > 0) {
    $ref_data = mysqli_fetch_assoc($check_ref);
    $new_role = $ref_data['assigned_role']; // Assigns 'reseller' or 'admin'
    
    // Update usage count
    mysqli_query($conn, "UPDATE referral_codes SET used_count = used_count + 1 WHERE id={$ref_data['id']}");
} else {
    $new_role = 'user'; // Default role
}

// Insert user with $new_role
$sql = "INSERT INTO users (username, password, role) VALUES ('$username', '$password', '$new_role')";
