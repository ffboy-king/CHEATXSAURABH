<?php
session_start();
include 'api/config.php'; // Database connect karein

if(isset($_POST['login'])){
    $user = $_POST['username'];
    $pass = $_POST['password'];
    
    // Simple Query (Security ke liye baad mein Hash use karein)
    $query = mysqli_query($conn, "SELECT * FROM users WHERE username='$user' AND password='$pass'");
    if(mysqli_num_rows($query) > 0){
        $data = mysqli_fetch_assoc($query);
        $_SESSION['user_id'] = $data['id'];
        $_SESSION['role'] = $data['role'];
        $_SESSION['username'] = $data['username'];
        header("Location: dashboard.php");
    } else {
        $error = "Invalid Username or Password";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>SAURABHXMOD PANEL</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        body { background-color: #121212; color: white; font-family: sans-serif; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }
        .login-box { background: #1e1e1e; padding: 30px; border-radius: 10px; box-shadow: 0 0 15px #6200ea; width: 300px; text-align: center; }
        input { width: 90%; padding: 10px; margin: 10px 0; background: #333; border: none; color: white; border-radius: 5px; }
        button { width: 100%; padding: 10px; background: #6200ea; color: white; border: none; border-radius: 5px; cursor: pointer; font-weight: bold; }
        button:hover { background: #3700b3; }
        .error { color: #ff4444; font-size: 12px; }
    </style>
</head>
<body>
    <div class="login-box">
        <h2>SAURABHXMOD PANEL</h2>
        <?php if(isset($error)) { echo "<p class='error'>$error</p>"; } ?>
        <form method="POST">
            <input type="text" name="username" placeholder="Username" required>
            <input type="password" name="password" placeholder="Password" required>
            <button type="submit" name="login">LOGIN</button>
        </form>
    </div>
</body>
</html>
