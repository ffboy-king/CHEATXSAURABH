<?php
// Only Owner can create Admin/Reseller invites
if ($_POST['create_invite']) {
    $role_to_give = $_POST['role']; // e.g., 'reseller'
    $code = "INVITE-" . rand(10000,99999);
    
    $sql = "INSERT INTO referral_codes (code, assigned_role, created_by) VALUES ('$code', '$role_to_give', '{$_SESSION['user_id']}')";
    mysqli_query($conn, $sql);
    echo "Give this code to your friend: $code. They will become a $role_to_give.";
}
?>
