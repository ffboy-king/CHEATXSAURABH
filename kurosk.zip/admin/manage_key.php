<?php
// ... DB connection and Admin check ...

if (isset($_POST['action'])) {
    $key_id = $_POST['key_id'];
    
    if ($_POST['action'] == 'expire_now') {
        // Force Expire
        mysqli_query($conn, "UPDATE license_keys SET status='expired', expires_at=NOW() WHERE id='$key_id'");
    } 
    elseif ($_POST['action'] == 'extend_validity') {
        // Add Days
        $days_to_add = intval($_POST['extra_days']);
        mysqli_query($conn, "UPDATE license_keys SET expires_at = DATE_ADD(expires_at, INTERVAL $days_to_add DAY) WHERE id='$key_id'");
    }
}
?>
