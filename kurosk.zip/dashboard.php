<?php
session_start();
include 'api/config.php';

// Login Check
if(!isset($_SESSION['user_id'])){ header("Location: index.php"); exit; }

// Handle Key Generation
$message = "";
if(isset($_POST['gen_keys'])){
    $duration = intval($_POST['days']);
    $amount = intval($_POST['amount']);
    $creator = $_SESSION['user_id'];
    
    for($i=0; $i<$amount; $i++){
        $key = "KURO-" . strtoupper(substr(md5(mt_rand()), 0, 8));
        mysqli_query($conn, "INSERT INTO license_keys (key_code, generated_by, duration_days) VALUES ('$key', '$creator', '$duration')");
    }
    $message = "$amount Keys Generated Successfully!";
}

// Handle Referral Code Creation (For Owners)
if(isset($_POST['create_ref']) && $_SESSION['role'] == 'owner'){
    $code = "REF-" . rand(1000,9999);
    $role = $_POST['ref_role'];
    mysqli_query($conn, "INSERT INTO referral_codes (code, assigned_role, created_by) VALUES ('$code', '$role', '{$_SESSION['user_id']}')");
    $message = "New Referral Code: $code (Role: $role)";
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Dashboard - Kuro Panel</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        body { background-color: #121212; color: #e0e0e0; font-family: 'Segoe UI', sans-serif; margin: 0; padding: 20px; }
        .container { max-width: 800px; margin: 0 auto; }
        .card { background: #1e1e1e; padding: 20px; margin-bottom: 20px; border-radius: 8px; border-left: 5px solid #6200ea; }
        h2, h3 { margin-top: 0; color: #bb86fc; }
        input, select { padding: 8px; background: #2c2c2c; border: 1px solid #444; color: white; border-radius: 4px; width: 40%; }
        button { padding: 8px 15px; background: #03dac6; border: none; color: black; font-weight: bold; border-radius: 4px; cursor: pointer; }
        table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        th, td { border-bottom: 1px solid #333; padding: 8px; text-align: left; font-size: 14px; }
        th { color: #03dac6; }
        .badge { padding: 2px 6px; border-radius: 4px; font-size: 12px; background: #333; }
        .active { color: #00ff00; }
        .expired { color: #ff4444; }
    </style>
</head>
<body>
    <div class="container">
        <div style="display:flex; justify-content:space-between; align-items:center;">
            <h2>Welcome, <?php echo $_SESSION['username']; ?> <span class="badge"><?php echo strtoupper($_SESSION['role']); ?></span></h2>
            <a href="logout.php" style="color:#ff4444; text-decoration:none;">Logout</a>
        </div>

        <?php if($message) echo "<p style='color:#00ff00;'>$message</p>"; ?>

        <!-- KEY GENERATOR SECTION -->
        <div class="card">
            <h3>⚡ Generate Keys</h3>
            <form method="POST">
                <input type="number" name="amount" placeholder="Amount (e.g. 10)" required>
                <select name="days">
                    <option value="1">1 Day</option>
                    <option value="7">7 Days</option>
                    <option value="30">30 Days</option>
                    <option value="365">1 Year</option>
                </select>
                <button type="submit" name="gen_keys">Generate</button>
            </form>
        </div>

        <!-- OWNER ONLY: REFERRAL SYSTEM -->
        <?php if($_SESSION['role'] == 'owner'): ?>
        <div class="card" style="border-left-color: #ff0266;">
            <h3>👥 Create Invite Code</h3>
            <form method="POST">
                <select name="ref_role">
                    <option value="reseller">Make Reseller</option>
                    <option value="admin">Make Admin</option>
                </select>
                <button type="submit" name="create_ref">Create Code</button>
            </form>
        </div>
        <?php endif; ?>

        <!-- RECENT KEYS TABLE -->
        <div class="card">
            <h3>🔑 Recent Keys</h3>
            <table>
                <tr>
                    <th>Key</th>
                    <th>Duration</th>
                    <th>Status</th>
                </tr>
                <?php
                $uid = $_SESSION['user_id'];
                $keys = mysqli_query($conn, "SELECT * FROM license_keys WHERE generated_by='$uid' ORDER BY id DESC LIMIT 10");
                while($row = mysqli_fetch_assoc($keys)){
                    $statusClass = ($row['status'] == 'active') ? 'active' : 'expired';
                    echo "<tr>
                            <td>{$row['key_code']}</td>
                            <td>{$row['duration_days']} Days</td>
                            <td class='$statusClass'>".strtoupper($row['status'])."</td>
                          </tr>";
                }
                ?>
            </table>
        </div>
    </div>
</body>
</html>
