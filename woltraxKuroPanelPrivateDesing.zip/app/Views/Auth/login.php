<?= $this->extend('Layout/Starter') ?>

<?= $this->section('content') ?>

<div class="login-container">
    <div class="background-image"></div>
    
    <div class="container min-vh-100 d-flex align-items-center justify-content-center position-relative">
        <div class="col-lg-8 col-md-10 col-sm-12">
            <?= $this->include('Layout/msgStatus') ?>
            
            <div class="split-panel">
                <!-- Left Panel (Red with Image) -->
                <div class="left-panel">
                    <div class="left-panel-image"></div>
                </div>
                
                <!-- Right Panel (Dark) -->
                <div class="right-panel">
                    <h2 class="panel-title">Giriş Yap</h2>
                    
                    <?= form_open() ?>
                    <div class="input-group">
                        <input type="text" class="form-input" name="username" id="username" placeholder="Kullanıcı Adı" required minlength="4">
                    </div>

                    <div class="input-group">
                        <input type="password" class="form-input" name="password" id="password" placeholder="Şifre" required minlength="6">
                    </div>

                    <input type="hidden" name="ip" value="<?php echo $_SERVER['HTTP_USER_AGENT']; ?>">

                    <div class="forgot-password">
                        <a href="#" class="forgot-link">Şifremi Unuttum?</a>
                    </div>

                    <div class="button-group">
                        <button type="submit" class="btn-primary">
                            Giriş Yap
                        </button>
                        <a href="<?= site_url('register') ?>" class="btn-secondary">
                            Kayıt Ol
                        </a>
                    </div>
                    <?= form_close() ?>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.login-container {
    position: relative;
    min-height: 100vh;
    background: transparent;
}

.background-image {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-image: url('/uploads/resimler/arkaplan.jpg');
    background-size: cover;
    background-position: center;
    background-repeat: no-repeat;
    z-index: -1;
}

.split-panel {
    display: flex;
    background: #fff;
    border-radius: 20px;
    overflow: hidden;
    box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3);
    max-width: 800px;
    width: 100%;
    min-height: 500px;
}

.left-panel {
    flex: 1;
    background: linear-gradient(135deg, #ff4757, #ff3742);
    position: relative;
    overflow: hidden;
}

.left-panel-image {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background-image: url('/uploads/resimler/resim.jpg');
    background-size: cover;
    background-position: center;
    background-repeat: no-repeat;
    opacity: 0.9;
    z-index: 1;
}

.left-panel::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(255, 71, 87, 0.2);
    pointer-events: none;
    z-index: 2;
}

.right-panel {
    flex: 1;
    background: linear-gradient(135deg, #2d3436, #1e2729);
    padding: 40px;
    display: flex;
    flex-direction: column;
    justify-content: center;
    position: relative;
}

.panel-title {
    color: #ff4757;
    font-size: 28px;
    font-weight: 700;
    margin-bottom: 30px;
    text-align: center;
    text-shadow: 0 0 10px rgba(255, 71, 87, 0.5);
}

.input-group {
    margin-bottom: 20px;
}

.form-input {
    width: 100%;
    padding: 15px 20px;
    border: none;
    border-radius: 25px;
    background: rgba(255, 255, 255, 0.1);
    color: white;
    font-size: 16px;
    backdrop-filter: blur(10px);
    transition: all 0.3s ease;
}

.form-input::placeholder {
    color: rgba(255, 255, 255, 0.7);
}

.form-input:focus {
    outline: none;
    background: rgba(255, 255, 255, 0.15);
    box-shadow: 0 0 20px rgba(255, 71, 87, 0.3);
}

.forgot-password {
    text-align: right;
    margin-bottom: 25px;
}

.forgot-link {
    color: #ff4757;
    text-decoration: none;
    font-size: 14px;
    transition: all 0.3s ease;
}

.forgot-link:hover {
    color: #ff6b7a;
    text-shadow: 0 0 10px rgba(255, 71, 87, 0.5);
}

.button-group {
    display: flex;
    flex-direction: column;
    gap: 15px;
    margin-bottom: 30px;
}

.btn-primary, .btn-secondary {
    width: 100%;
    padding: 15px;
    border: none;
    border-radius: 25px;
    font-size: 16px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s ease;
    text-decoration: none;
    text-align: center;
}

.btn-primary {
    background: linear-gradient(45deg, #ff4757, #ff3742);
    color: white;
    box-shadow: 0 5px 15px rgba(255, 71, 87, 0.3);
}

.btn-primary:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 25px rgba(255, 71, 87, 0.4);
    color: white;
}

.btn-secondary {
    background: linear-gradient(45deg, #ff4757, #ff3742);
    color: white;
    box-shadow: 0 5px 15px rgba(255, 71, 87, 0.3);
}

.btn-secondary:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 25px rgba(255, 71, 87, 0.4);
    color: white;
}

/* Responsive Design */
@media (max-width: 768px) {
    .split-panel {
        flex-direction: column;
        min-height: auto;
    }
    
    .left-panel, .right-panel {
        padding: 30px 20px;
    }
    
    .panel-title {
        font-size: 24px;
    }
}

/* Animation */
@keyframes glow {
    0%, 100% {
        box-shadow: 0 0 20px rgba(255, 71, 87, 0.3);
    }
    50% {
        box-shadow: 0 0 30px rgba(255, 71, 87, 0.5);
    }
}

.split-panel {
    animation: glow 3s ease-in-out infinite;
}
</style>

<?= $this->endSection() ?>