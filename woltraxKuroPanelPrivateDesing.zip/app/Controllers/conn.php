<?php

$servername = "mysql-cheatxsaurabh.alwaysdata.net";
$username = "444399_mod";
$password = "saurabh9057";
$dbname = "cheatxsaurabh_mod";

$conn = mysqli_connect($servername,$username,$password,$dbname);

if(!$conn) {

die(" PROBLEM WITH CONNECTION : " . mysqli_connect_error());

}
  
?>