import { useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { useNavigate, useLocation } from "react-router-dom";
import { LayoutDashboard, Wallet, ShoppingCart, Key, Clock, Users, User, LogOut, X, Shield } from "lucide-react";

const menuItems = [
  { icon: LayoutDashboard, label: "Dashboard", path: "/dashboard" },
  { icon: Wallet, label: "Deposit", path: "/deposit" },
  { icon: ShoppingCart, label: "Buy Keys", path: "/store" },
  { icon: Key, label: "My Keys", path: "/my-keys" },
  { icon: Clock, label: "History", path: "/history" },
  { icon: Users, label: "Refer & Earn", path: "/referral" },
];

const settingsItems = [
  { icon: User, label: "My Profile", path: "/profile" },
];

interface AppSidebarProps {
  open: boolean;
  onClose: () => void;
}

export default function AppSidebar({ open, onClose }: AppSidebarProps) {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  const handleNav = (path: string) => {
    navigate(path);
    onClose();
  };

  const handleLogout = () => {
    logout();
    navigate("/login");
    onClose();
  };

  return (
    <>
      {/* Overlay */}
      {open && (
        <div className="fixed inset-0 bg-background/60 backdrop-blur-sm z-40" onClick={onClose} />
      )}
      {/* Sidebar */}
      <div className={`fixed top-0 left-0 h-full w-72 bg-sidebar z-50 transform transition-transform duration-300 ${open ? "translate-x-0" : "-translate-x-full"} border-r border-sidebar-border`}>
        <div className="p-5">
          {/* Header */}
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full neon-border-cyan flex items-center justify-center">
                <Shield className="w-5 h-5 text-primary" />
              </div>
              <span className="font-display text-lg font-bold tracking-wider neon-text-cyan">FF PANELS</span>
            </div>
            <button onClick={onClose} className="text-muted-foreground hover:text-foreground">
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Menu */}
          <nav className="space-y-1">
            {menuItems.map((item) => {
              const active = location.pathname === item.path;
              return (
                <button
                  key={item.path}
                  onClick={() => handleNav(item.path)}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg text-base font-medium transition-all ${
                    active
                      ? "bg-primary/15 text-primary neon-border-cyan"
                      : "text-sidebar-foreground hover:bg-sidebar-accent"
                  }`}
                >
                  <item.icon className="w-5 h-5" />
                  {item.label}
                </button>
              );
            })}
          </nav>

          {/* Settings */}
          <div className="mt-6 pt-4 border-t border-sidebar-border">
            <p className="text-xs text-neon-magenta font-display tracking-widest uppercase mb-3 px-4">Settings</p>
            {settingsItems.map((item) => {
              const active = location.pathname === item.path;
              return (
                <button
                  key={item.path}
                  onClick={() => handleNav(item.path)}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg text-base font-medium transition-all ${
                    active
                      ? "bg-primary/15 text-primary"
                      : "text-sidebar-foreground hover:bg-sidebar-accent"
                  }`}
                >
                  <item.icon className="w-5 h-5" />
                  {item.label}
                </button>
              );
            })}
            <button
              onClick={handleLogout}
              className="w-full flex items-center gap-3 px-4 py-3 rounded-lg text-base font-medium text-destructive hover:bg-destructive/10 transition-all"
            >
              <LogOut className="w-5 h-5" />
              Logout
            </button>
          </div>

          {/* User info */}
          {user && (
            <div className="absolute bottom-6 left-5 right-5 glass-card rounded-lg p-3">
              <p className="text-sm font-semibold text-foreground truncate">@{user.username}</p>
              <p className={`text-xs font-display tracking-wider ${user.role === "reseller" ? "text-neon-magenta" : "text-primary"}`}>
                {user.role.toUpperCase()}
              </p>
            </div>
          )}
        </div>
      </div>
    </>
  );
}
