// App store using localStorage for demo

export type UserRole = "user" | "reseller";
export type ResellerStatus = "none" | "pending" | "approved" | "rejected";
export type OrderStatus = "pending" | "delivered" | "cancelled";
export type DepositStatus = "pending" | "approved" | "rejected";

export interface DepositRequest {
  id: string;
  userId: string;
  username: string;
  amount: number;
  utrNumber: string;
  status: DepositStatus;
  createdAt: string;
  processedAt?: string;
}

export interface User {
  id: string;
  username: string;
  email: string;
  password: string;
  role: UserRole;
  balance: number;
  referralCode: string;
  referredBy?: string;
  resellerStatus: ResellerStatus;
  createdAt: string;
}

export interface Product {
  id: string;
  category: string;
  name: string;
  features: string[];
  variants: ProductVariant[];
}

export interface ProductVariant {
  id: string;
  duration: string;
  type: string;
  userPrice: number;
  resellerPrice: number;
  inStock: boolean;
}

export interface Order {
  id: string;
  userId: string;
  username: string;
  productName: string;
  variantId: string;
  duration: string;
  type: string;
  price: number;
  status: OrderStatus;
  keyCode?: string;
  createdAt: string;
  deliveredAt?: string;
}

export interface Transaction {
  id: string;
  userId: string;
  type: "deposit" | "purchase" | "referral" | "spin" | "reseller_fee";
  amount: number;
  status: "success" | "pending" | "failed";
  description: string;
  createdAt: string;
}

export interface ResellerApplication {
  id: string;
  userId: string;
  username: string;
  email: string;
  status: "pending" | "approved" | "rejected";
  createdAt: string;
}

// Default admin credentials
const ADMIN_USERNAME = "owner";
const ADMIN_PASSWORD = "owner123";
const RESELLER_FEE = 500;

export { RESELLER_FEE };

// Products data
export const DEFAULT_PRODUCTS: Product[] = [
  {
    id: "br-mod-ff",
    category: "FF PANELS",
    name: "BR MOD FF",
    features: ["Silent Aim", "Aim Magnet", "Speed"],
    variants: [
      { id: "br-1d-mob", duration: "1 Day", type: "Mobile", userPrice: 79, resellerPrice: 50, inStock: true },
      { id: "br-7d-mob", duration: "7 Days", type: "Mobile", userPrice: 319, resellerPrice: 150, inStock: true },
      { id: "br-15d-mob", duration: "15 Days", type: "Mobile", userPrice: 559, resellerPrice: 300, inStock: true },
      { id: "br-30d-mob", duration: "30 Days", type: "Mobile", userPrice: 799, resellerPrice: 450, inStock: true },
      { id: "br-1d-pc", duration: "1 Day", type: "PC Aim Silent", userPrice: 79, resellerPrice: 50, inStock: true },
      { id: "br-10d-pc", duration: "10 Days", type: "PC Aim Silent", userPrice: 479, resellerPrice: 250, inStock: true },
      { id: "br-30d-pc", duration: "30 Days", type: "PC Aim Silent", userPrice: 799, resellerPrice: 499, inStock: true },
      { id: "br-10d-bypass", duration: "10 Days", type: "PC Bypass + Silent", userPrice: 519, resellerPrice: 279, inStock: true },
      { id: "br-30d-bypass", duration: "30 Days", type: "PC Bypass + Silent", userPrice: 959, resellerPrice: 599, inStock: true },
      { id: "br-1d-bypass", duration: "1 Day", type: "PC Bypass + Silent", userPrice: 119, resellerPrice: 79, inStock: true },
    ],
  },
  {
    id: "dripclient-ff",
    category: "FF PANELS",
    name: "DRIPCLIENT FF",
    features: ["Aimkill", "Silent Aim", "Underkill"],
    variants: [
      { id: "drip-1d-nr", duration: "1 Day", type: "NONROOT", userPrice: 90, resellerPrice: 49, inStock: true },
      { id: "drip-7d-nr", duration: "7 Days", type: "NONROOT", userPrice: 350, resellerPrice: 149, inStock: true },
      { id: "drip-15d-nr", duration: "15 Days", type: "NONROOT", userPrice: 600, resellerPrice: 249, inStock: true },
      { id: "drip-30d-nr", duration: "30 Days", type: "NONROOT", userPrice: 900, resellerPrice: 349, inStock: true },
      { id: "drip-1d-r", duration: "1 Day", type: "ROOT", userPrice: 90, resellerPrice: 49, inStock: true },
      { id: "drip-7d-r", duration: "7 Days", type: "ROOT", userPrice: 350, resellerPrice: 149, inStock: true },
      { id: "drip-30d-r", duration: "30 Days", type: "ROOT", userPrice: 900, resellerPrice: 349, inStock: true },
      { id: "drip-1d-pcaim", duration: "1 Day", type: "PC AIMKILL", userPrice: 150, resellerPrice: 79, inStock: true },
      { id: "drip-7d-pcaim", duration: "7 Days", type: "PC AIMKILL", userPrice: 450, resellerPrice: 199, inStock: true },
      { id: "drip-15d-pcaim", duration: "15 Days", type: "PC AIMKILL", userPrice: 750, resellerPrice: 349, inStock: true },
      { id: "drip-30d-pcaim", duration: "30 Days", type: "PC AIMKILL", userPrice: 1050, resellerPrice: 449, inStock: true },
      { id: "drip-3d-nr", duration: "3 Days", type: "NONROOT", userPrice: 199, resellerPrice: 79, inStock: true },
    ],
  },
  {
    id: "hg-cheats-ff",
    category: "FF PANELS",
    name: "HG CHEATS FF",
    features: ["Aim Magnet", "Silent Aim", "Aimbot"],
    variants: [
      { id: "hg-1d", duration: "1 Day", type: "Standard", userPrice: 133, resellerPrice: 79, inStock: true },
      { id: "hg-7d", duration: "7 Days", type: "Standard", userPrice: 300, resellerPrice: 135, inStock: true },
      { id: "hg-10d", duration: "10 Days", type: "Standard", userPrice: 313, resellerPrice: 149, inStock: true },
      { id: "hg-30d", duration: "30 Days", type: "Standard", userPrice: 718, resellerPrice: 299, inStock: true },
    ],
  },
  {
    id: "hikari-mod-ff",
    category: "FF PANELS",
    name: "HIKARI MOD FF",
    features: ["Aimbot", "Headshot"],
    variants: [
      { id: "hik-3d", duration: "3 Days", type: "Aimsafe Root", userPrice: 149, resellerPrice: 49, inStock: true },
      { id: "hik-7d", duration: "7 Days", type: "Aimsafe Root", userPrice: 259, resellerPrice: 99, inStock: true },
      { id: "hik-15d", duration: "15 Days", type: "Aimsafe Root", userPrice: 499, resellerPrice: 189, inStock: true },
      { id: "hik-30d", duration: "30 Days", type: "Aimsafe Root", userPrice: 699, resellerPrice: 299, inStock: true },
    ],
  },
  {
    id: "ios-fluorite-ff",
    category: "FF PANELS",
    name: "IOS FLUORITE FF",
    features: ["Silent Aim", "Aimbot", "Speed"],
    variants: [
      { id: "ios-1d", duration: "1 Day", type: "Fluorite FF", userPrice: 450, resellerPrice: 199, inStock: true },
      { id: "ios-7d", duration: "7 Days", type: "Fluorite FF", userPrice: 1350, resellerPrice: 599, inStock: true },
      { id: "ios-30d", duration: "30 Days", type: "Fluorite FF", userPrice: 2250, resellerPrice: 1099, inStock: true },
      { id: "ios-esign", duration: "Lifetime", type: "Esign Certificate", userPrice: 699, resellerPrice: 419, inStock: true },
      { id: "ios-signer", duration: "Lifetime", type: "Signer Certificate", userPrice: 999, resellerPrice: 699, inStock: true },
    ],
  },
  {
    id: "kos-root-ff",
    category: "FF PANELS",
    name: "KOS ROOT FF",
    features: ["Aimbot", "Headshot"],
    variants: [
      { id: "kos-1d", duration: "1 Day", type: "Aimsafe Root", userPrice: 149, resellerPrice: 79, inStock: true },
    ],
  },
  {
    id: "pato-team-ff",
    category: "FF PANELS",
    name: "PATO TEAM FF",
    features: ["Silent Aim", "Aim Magnet", "Speed"],
    variants: [
      { id: "pato-3d", duration: "3 Days", type: "Safe", userPrice: 329, resellerPrice: 149, inStock: true },
      { id: "pato-7d", duration: "7 Days", type: "Standard", userPrice: 500, resellerPrice: 200, inStock: true },
      { id: "pato-7d-brutal", duration: "7 Days", type: "Brutal", userPrice: 549, resellerPrice: 249, inStock: true },
      { id: "pato-15d", duration: "15 Days", type: "Standard", userPrice: 700, resellerPrice: 388, inStock: true },
      { id: "pato-30d", duration: "30 Days", type: "Standard", userPrice: 900, resellerPrice: 469, inStock: true },
    ],
  },
  {
    id: "prime-hook-ff",
    category: "FF PANELS",
    name: "PRIME HOOK FF",
    features: ["Aim Magnet", "Silent Aim", "Aimbot"],
    variants: [
      { id: "prime-5d", duration: "5 Days", type: "Mod", userPrice: 176, resellerPrice: 75, inStock: true },
      { id: "prime-10d", duration: "10 Days", type: "Mod", userPrice: 351, resellerPrice: 150, inStock: true },
    ],
  },
  {
    id: "xyz-cheats-ff",
    category: "FF PANELS",
    name: "XYZ CHEATS FF",
    features: ["Aimbot", "Headshot"],
    variants: [
      { id: "xyz-3d", duration: "3 Days", type: "Aimsafe Root", userPrice: 149, resellerPrice: 49, inStock: true },
      { id: "xyz-7d", duration: "7 Days", type: "Aimsafe Root", userPrice: 259, resellerPrice: 99, inStock: true },
      { id: "xyz-15d", duration: "15 Days", type: "Aimsafe Root", userPrice: 499, resellerPrice: 189, inStock: true },
      { id: "xyz-30d", duration: "30 Days", type: "Aimsafe Root", userPrice: 699, resellerPrice: 299, inStock: true },
    ],
  },
];

// Storage keys
const USERS_KEY = "ff_panels_users";
const CURRENT_USER_KEY = "ff_panels_current_user";
const ORDERS_KEY = "ff_panels_orders";
const TRANSACTIONS_KEY = "ff_panels_transactions";
const PRODUCTS_KEY = "ff_panels_products";
const RESELLER_APPS_KEY = "ff_panels_reseller_apps";
const ADMIN_LOGGED_IN_KEY = "ff_panels_admin";
const DEPOSIT_REQUESTS_KEY = "ff_panels_deposit_requests";

function getFromStorage<T>(key: string, fallback: T): T {
  try {
    const data = localStorage.getItem(key);
    return data ? JSON.parse(data) : fallback;
  } catch { return fallback; }
}

function setToStorage<T>(key: string, data: T) {
  localStorage.setItem(key, JSON.stringify(data));
}

// ============ PRODUCTS ============
export function getProducts(): Product[] {
  return getFromStorage<Product[]>(PRODUCTS_KEY, DEFAULT_PRODUCTS);
}

export function saveProducts(products: Product[]) {
  setToStorage(PRODUCTS_KEY, products);
}

export function updateProductPrices(productId: string, variantId: string, userPrice: number, resellerPrice: number) {
  const products = getProducts();
  const pIdx = products.findIndex(p => p.id === productId);
  if (pIdx === -1) return;
  const vIdx = products[pIdx].variants.findIndex(v => v.id === variantId);
  if (vIdx === -1) return;
  products[pIdx].variants[vIdx].userPrice = userPrice;
  products[pIdx].variants[vIdx].resellerPrice = resellerPrice;
  saveProducts(products);
}

export function toggleVariantStock(productId: string, variantId: string) {
  const products = getProducts();
  const pIdx = products.findIndex(p => p.id === productId);
  if (pIdx === -1) return;
  const vIdx = products[pIdx].variants.findIndex(v => v.id === variantId);
  if (vIdx === -1) return;
  products[pIdx].variants[vIdx].inStock = !products[pIdx].variants[vIdx].inStock;
  saveProducts(products);
}

// ============ USERS ============
export function getUsers(): User[] {
  return getFromStorage<User[]>(USERS_KEY, []);
}

export function getCurrentUser(): User | null {
  return getFromStorage<User | null>(CURRENT_USER_KEY, null);
}

export function setCurrentUser(user: User | null) {
  setToStorage(CURRENT_USER_KEY, user);
}

export function refreshCurrentUserFromStore(): User | null {
  const current = getCurrentUser();
  if (!current) return null;
  const users = getUsers();
  const updated = users.find(u => u.id === current.id);
  if (updated) {
    setCurrentUser(updated);
    return updated;
  }
  return current;
}

export function registerUser(username: string, email: string, password: string): User {
  const users = getUsers();
  if (username.toLowerCase() === ADMIN_USERNAME) throw new Error("This username is reserved");
  if (users.find(u => u.username.toLowerCase() === username.toLowerCase())) throw new Error("Username already exists");
  if (users.find(u => u.email.toLowerCase() === email.toLowerCase())) throw new Error("Email already exists");
  const user: User = {
    id: crypto.randomUUID(),
    username,
    email,
    password,
    role: "user",
    balance: 0,
    referralCode: Math.random().toString(36).substring(2, 8).toUpperCase(),
    resellerStatus: "none",
    createdAt: new Date().toISOString(),
  };
  users.push(user);
  setToStorage(USERS_KEY, users);
  return user;
}

export function loginUser(username: string, password: string): User {
  const users = getUsers();
  const user = users.find(u => u.username.toLowerCase() === username.toLowerCase() && u.password === password);
  if (!user) throw new Error("Invalid username or password");
  setCurrentUser(user);
  return user;
}

export function logoutUser() {
  setCurrentUser(null);
}

export function updateUserBalance(userId: string, amount: number) {
  const users = getUsers();
  const idx = users.findIndex(u => u.id === userId);
  if (idx === -1) return;
  users[idx].balance += amount;
  setToStorage(USERS_KEY, users);
  const current = getCurrentUser();
  if (current && current.id === userId) {
    current.balance = users[idx].balance;
    setCurrentUser(current);
  }
}

export function updateUserPassword(userId: string, newPassword: string) {
  const users = getUsers();
  const idx = users.findIndex(u => u.id === userId);
  if (idx === -1) return;
  users[idx].password = newPassword;
  setToStorage(USERS_KEY, users);
}

// ============ ADMIN ============
export function adminLogin(username: string, password: string): boolean {
  if (username === ADMIN_USERNAME && password === ADMIN_PASSWORD) {
    setToStorage(ADMIN_LOGGED_IN_KEY, true);
    return true;
  }
  return false;
}

export function isAdminLoggedIn(): boolean {
  return getFromStorage(ADMIN_LOGGED_IN_KEY, false);
}

export function adminLogout() {
  setToStorage(ADMIN_LOGGED_IN_KEY, false);
}

export function adminSetUserBalance(userId: string, newBalance: number) {
  const users = getUsers();
  const idx = users.findIndex(u => u.id === userId);
  if (idx === -1) return;
  users[idx].balance = newBalance;
  setToStorage(USERS_KEY, users);
}

export function adminAddUserBalance(userId: string, amount: number) {
  const users = getUsers();
  const idx = users.findIndex(u => u.id === userId);
  if (idx === -1) return;
  users[idx].balance += amount;
  setToStorage(USERS_KEY, users);
}

// ============ RESELLER APPLICATIONS ============
export function applyForReseller(userId: string): void {
  const users = getUsers();
  const user = users.find(u => u.id === userId);
  if (!user) throw new Error("User not found");
  if (user.balance < RESELLER_FEE) throw new Error(`Insufficient balance! ₹${RESELLER_FEE} required.`);
  if (user.resellerStatus === "pending") throw new Error("Application already pending");
  if (user.role === "reseller") throw new Error("Already a reseller");

  // Deduct fee
  updateUserBalance(userId, -RESELLER_FEE);
  addTransaction({
    userId,
    type: "reseller_fee",
    amount: RESELLER_FEE,
    status: "success",
    description: "Reseller Application Fee",
  });

  // Update user status
  const updatedUsers = getUsers();
  const uIdx = updatedUsers.findIndex(u => u.id === userId);
  updatedUsers[uIdx].resellerStatus = "pending";
  setToStorage(USERS_KEY, updatedUsers);

  // Add application
  const apps = getResellerApplications();
  apps.unshift({
    id: crypto.randomUUID(),
    userId,
    username: user.username,
    email: user.email,
    status: "pending",
    createdAt: new Date().toISOString(),
  });
  setToStorage(RESELLER_APPS_KEY, apps);
}

export function getResellerApplications(): ResellerApplication[] {
  return getFromStorage<ResellerApplication[]>(RESELLER_APPS_KEY, []);
}

export function approveReseller(appId: string) {
  const apps = getResellerApplications();
  const appIdx = apps.findIndex(a => a.id === appId);
  if (appIdx === -1) return;
  apps[appIdx].status = "approved";
  setToStorage(RESELLER_APPS_KEY, apps);

  // Update user role
  const users = getUsers();
  const uIdx = users.findIndex(u => u.id === apps[appIdx].userId);
  if (uIdx !== -1) {
    users[uIdx].role = "reseller";
    users[uIdx].resellerStatus = "approved";
    setToStorage(USERS_KEY, users);
  }
}

export function rejectReseller(appId: string) {
  const apps = getResellerApplications();
  const appIdx = apps.findIndex(a => a.id === appId);
  if (appIdx === -1) return;
  apps[appIdx].status = "rejected";
  setToStorage(RESELLER_APPS_KEY, apps);

  // Update user status + refund
  const users = getUsers();
  const uIdx = users.findIndex(u => u.id === apps[appIdx].userId);
  if (uIdx !== -1) {
    users[uIdx].resellerStatus = "rejected";
    users[uIdx].balance += RESELLER_FEE;
    setToStorage(USERS_KEY, users);
    addTransaction({
      userId: users[uIdx].id,
      type: "reseller_fee",
      amount: RESELLER_FEE,
      status: "success",
      description: "Reseller Application Rejected - Refund",
    });
  }
}

// ============ ORDERS ============
export function createOrder(order: Omit<Order, "id" | "createdAt" | "status">): Order {
  const orders = getOrders();
  const newOrder: Order = {
    ...order,
    id: "#" + Math.floor(10000 + Math.random() * 90000),
    status: "pending",
    createdAt: new Date().toISOString(),
  };
  orders.unshift(newOrder);
  setToStorage(ORDERS_KEY, orders);
  return newOrder;
}

export function getOrders(): Order[] {
  return getFromStorage<Order[]>(ORDERS_KEY, []);
}

export function getUserOrders(userId: string): Order[] {
  return getOrders().filter(o => o.userId === userId);
}

export function deliverOrder(orderId: string, keyCode: string) {
  const orders = getOrders();
  const idx = orders.findIndex(o => o.id === orderId);
  if (idx === -1) return;
  orders[idx].status = "delivered";
  orders[idx].keyCode = keyCode;
  orders[idx].deliveredAt = new Date().toISOString();
  setToStorage(ORDERS_KEY, orders);
}

export function cancelOrder(orderId: string) {
  const orders = getOrders();
  const idx = orders.findIndex(o => o.id === orderId);
  if (idx === -1) return;
  const order = orders[idx];
  orders[idx].status = "cancelled";
  setToStorage(ORDERS_KEY, orders);

  // Refund
  updateUserBalance(order.userId, order.price);
  addTransaction({
    userId: order.userId,
    type: "purchase",
    amount: order.price,
    status: "success",
    description: `Order ${orderId} cancelled - Refund`,
  });
}

// ============ TRANSACTIONS ============
export function addTransaction(tx: Omit<Transaction, "id" | "createdAt">) {
  const txs = getFromStorage<Transaction[]>(TRANSACTIONS_KEY, []);
  txs.unshift({
    ...tx,
    id: "#" + Math.floor(10000 + Math.random() * 90000),
    createdAt: new Date().toISOString(),
  });
  setToStorage(TRANSACTIONS_KEY, txs);
}

export function getTransactions(userId?: string): Transaction[] {
  const txs = getFromStorage<Transaction[]>(TRANSACTIONS_KEY, []);
  if (userId) return txs.filter(t => t.userId === userId);
  return txs;
}

export const TOP_SELLERS = [
  { rank: 1, username: "@Jituuuu", type: "RESELLER" },
  { rank: 2, username: "@DARKBHAI", type: "RESELLER" },
  { rank: 3, username: "@RoniModMenu", type: "RESELLER" },
  { rank: 4, username: "@SUBHAJIT", type: "RESELLER" },
  { rank: 5, username: "@jack_07", type: "RESELLER" },
];

// ============ DEPOSIT REQUESTS ============
export function getDepositRequests(): DepositRequest[] {
  return getFromStorage<DepositRequest[]>(DEPOSIT_REQUESTS_KEY, []);
}

export function createDepositRequest(userId: string, username: string, amount: number, utrNumber: string): DepositRequest {
  const requests = getDepositRequests();
  const req: DepositRequest = {
    id: crypto.randomUUID(),
    userId,
    username,
    amount,
    utrNumber,
    status: "pending",
    createdAt: new Date().toISOString(),
  };
  requests.unshift(req);
  setToStorage(DEPOSIT_REQUESTS_KEY, requests);
  return req;
}

export function approveDeposit(requestId: string) {
  const requests = getDepositRequests();
  const idx = requests.findIndex(r => r.id === requestId);
  if (idx === -1) return;
  const req = requests[idx];
  requests[idx].status = "approved";
  requests[idx].processedAt = new Date().toISOString();
  setToStorage(DEPOSIT_REQUESTS_KEY, requests);

  // Add balance
  updateUserBalance(req.userId, req.amount);
  addTransaction({
    userId: req.userId,
    type: "deposit",
    amount: req.amount,
    status: "success",
    description: `UPI Deposit Approved - ₹${req.amount} (UTR: ${req.utrNumber})`,
  });
}

export function rejectDeposit(requestId: string) {
  const requests = getDepositRequests();
  const idx = requests.findIndex(r => r.id === requestId);
  if (idx === -1) return;
  requests[idx].status = "rejected";
  requests[idx].processedAt = new Date().toISOString();
  setToStorage(DEPOSIT_REQUESTS_KEY, requests);
}
