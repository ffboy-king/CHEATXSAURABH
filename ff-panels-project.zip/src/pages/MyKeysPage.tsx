import { useAuth } from "@/contexts/AuthContext";
import { getUserOrders } from "@/lib/store";
import { Key, Search, ShoppingCart, Clock, CheckCircle, XCircle } from "lucide-react";
import { useState } from "react";
import { useNavigate } from "react-router-dom";

export default function MyKeysPage() {
  const { user } = useAuth();
  const [search, setSearch] = useState("");
  const navigate = useNavigate();
  if (!user) return null;

  const orders = getUserOrders(user.id);
  const deliveredOrders = orders.filter(o => o.status === "delivered");
  const pendingOrders = orders.filter(o => o.status === "pending");
  const filtered = orders.filter(o =>
    o.productName.toLowerCase().includes(search.toLowerCase()) ||
    (o.keyCode && o.keyCode.toLowerCase().includes(search.toLowerCase()))
  );

  const statusIcon = (status: string) => {
    switch (status) {
      case "pending": return <Clock className="w-4 h-4 text-neon-yellow" />;
      case "delivered": return <CheckCircle className="w-4 h-4 text-neon-green" />;
      case "cancelled": return <XCircle className="w-4 h-4 text-destructive" />;
      default: return null;
    }
  };

  return (
    <div className="p-4 space-y-5 animate-slide-up">
      <h1 className="font-display font-bold text-lg tracking-wider neon-text-cyan flex items-center gap-2">
        <Key className="w-5 h-5" /> MY ORDERS & KEYS
      </h1>

      <div className="relative">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <input
          type="text"
          placeholder="Search Key or Product..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-full bg-input border border-border/50 rounded-lg pl-10 pr-4 py-3 text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary"
        />
      </div>

      <button
        onClick={() => navigate("/store")}
        className="w-full bg-primary text-primary-foreground font-display font-bold tracking-widest py-3 rounded-lg hover:brightness-110 transition-all flex items-center justify-center gap-2"
      >
        <ShoppingCart className="w-5 h-5" /> BUY NEW KEYS
      </button>

      <div className="grid grid-cols-3 gap-3">
        <div className="glass-card rounded-lg p-3 text-center">
          <p className="text-xs text-muted-foreground font-display tracking-wider">TOTAL</p>
          <p className="text-xl font-bold text-foreground">{orders.length}</p>
        </div>
        <div className="glass-card rounded-lg p-3 text-center neon-border-cyan">
          <p className="text-xs text-muted-foreground font-display tracking-wider">DELIVERED</p>
          <p className="text-xl font-bold text-neon-green">{deliveredOrders.length}</p>
        </div>
        <div className="glass-card rounded-lg p-3 text-center">
          <p className="text-xs text-neon-yellow font-display tracking-wider">PENDING</p>
          <p className="text-xl font-bold text-neon-yellow">{pendingOrders.length}</p>
        </div>
      </div>

      {filtered.length === 0 ? (
        <div className="glass-card rounded-xl p-8 text-center neon-border-cyan">
          <Key className="w-12 h-12 text-muted-foreground mx-auto mb-3" />
          <p className="text-muted-foreground">No orders yet</p>
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map((o) => (
            <div key={o.id} className={`glass-card rounded-xl p-4 border ${o.status === "delivered" ? "border-neon-green/30" : o.status === "pending" ? "border-neon-yellow/30" : "border-destructive/30"}`}>
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center gap-2">
                    {statusIcon(o.status)}
                    <span className="text-xs font-display tracking-wider uppercase" style={{
                      color: o.status === "delivered" ? "hsl(var(--neon-green))" : o.status === "pending" ? "hsl(var(--neon-yellow))" : "hsl(var(--destructive))"
                    }}>{o.status}</span>
                  </div>
                  <p className="font-semibold text-foreground mt-1">{o.productName}</p>
                  <p className="text-sm text-primary">{o.duration} {o.type}</p>
                  <p className="text-xs text-muted-foreground mt-1">{new Date(o.createdAt).toLocaleString()}</p>
                </div>
                <div className="text-right">
                  {o.keyCode ? (
                    <p className="font-mono text-sm text-neon-green font-bold">{o.keyCode}</p>
                  ) : (
                    <p className="text-xs text-neon-yellow">Awaiting delivery</p>
                  )}
                  <p className="text-sm text-foreground font-semibold mt-1">₹{o.price.toFixed(2)}</p>
                  <p className="text-xs text-muted-foreground font-mono">{o.id}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
