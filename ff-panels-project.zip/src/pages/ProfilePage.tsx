import { useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { updateUserPassword } from "@/lib/store";
import { User, Lock, Mail, Shield } from "lucide-react";
import { toast } from "sonner";

export default function ProfilePage() {
  const { user } = useAuth();
  const [currentPass, setCurrentPass] = useState("");
  const [newPass, setNewPass] = useState("");
  const [confirmPass, setConfirmPass] = useState("");
  if (!user) return null;

  const handleUpdatePassword = () => {
    if (currentPass !== user.password) {
      toast.error("Current password is incorrect");
      return;
    }
    if (newPass.length < 4) {
      toast.error("Password must be at least 4 characters");
      return;
    }
    if (newPass !== confirmPass) {
      toast.error("Passwords do not match");
      return;
    }
    updateUserPassword(user.id, newPass);
    toast.success("Password updated successfully!");
    setCurrentPass("");
    setNewPass("");
    setConfirmPass("");
  };

  return (
    <div className="p-4 space-y-5 animate-slide-up">
      <h1 className="font-display font-bold text-lg tracking-wider neon-text-cyan flex items-center gap-2">
        <User className="w-5 h-5" /> ACCOUNT PROFILE
      </h1>

      {/* Info */}
      <div className="glass-card rounded-xl p-5 neon-border-cyan">
        <h2 className="font-display font-bold tracking-wider text-foreground mb-4">INFORMATION</h2>
        <div className="space-y-3">
          <div className="flex items-center justify-between bg-muted/20 rounded-lg p-3">
            <span className="text-sm text-muted-foreground flex items-center gap-2"><User className="w-4 h-4" /> USERNAME</span>
            <span className="text-sm font-semibold text-foreground">{user.username}</span>
          </div>
          <div className="flex items-center justify-between bg-muted/20 rounded-lg p-3">
            <span className="text-sm text-muted-foreground flex items-center gap-2"><Mail className="w-4 h-4" /> EMAIL</span>
            <span className="text-sm font-semibold text-foreground">{user.email}</span>
          </div>
          <div className="flex items-center justify-between bg-muted/20 rounded-lg p-3">
            <span className="text-sm text-muted-foreground flex items-center gap-2"><Shield className="w-4 h-4" /> ROLE</span>
            <span className={`text-sm font-bold font-display tracking-wider ${user.role === "reseller" ? "text-secondary" : "text-primary"}`}>
              {user.role.toUpperCase()}
            </span>
          </div>
          <div className="flex items-center justify-between bg-muted/20 rounded-lg p-3">
            <span className="text-sm text-muted-foreground">BALANCE</span>
            <span className="text-sm font-bold text-foreground">₹{user.balance.toFixed(2)}</span>
          </div>
        </div>
      </div>

      {/* Security */}
      <div className="glass-card rounded-xl p-5 neon-border-magenta">
        <h2 className="font-display font-bold tracking-wider text-foreground mb-4 flex items-center gap-2">
          <Lock className="w-4 h-4" /> SECURITY UPDATE
        </h2>
        <div className="space-y-3">
          <input
            type="password"
            placeholder="CURRENT PASSWORD"
            value={currentPass}
            onChange={(e) => setCurrentPass(e.target.value)}
            className="w-full bg-input border border-border/50 rounded-lg px-4 py-3 text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary"
          />
          <input
            type="password"
            placeholder="NEW PASSWORD"
            value={newPass}
            onChange={(e) => setNewPass(e.target.value)}
            className="w-full bg-input border border-border/50 rounded-lg px-4 py-3 text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary"
          />
          <input
            type="password"
            placeholder="CONFIRM NEW PASSWORD"
            value={confirmPass}
            onChange={(e) => setConfirmPass(e.target.value)}
            className="w-full bg-input border border-border/50 rounded-lg px-4 py-3 text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary"
          />
          <button
            onClick={handleUpdatePassword}
            className="w-full bg-secondary text-secondary-foreground font-display font-bold tracking-widest py-3 rounded-lg hover:brightness-110 transition-all"
          >
            UPDATE PASSWORD
          </button>
        </div>
      </div>
    </div>
  );
}
