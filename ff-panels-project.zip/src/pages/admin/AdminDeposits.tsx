import { useState } from "react";
import { getDepositRequests, approveDeposit, rejectDeposit } from "@/lib/store";
import { CheckCircle, XCircle, Clock, IndianRupee } from "lucide-react";
import { toast } from "sonner";

export default function AdminDeposits() {
  const [refresh, setRefresh] = useState(0);
  const requests = getDepositRequests();
  const pending = requests.filter(r => r.status === "pending");
  const processed = requests.filter(r => r.status !== "pending");

  const handleApprove = (id: string, username: string, amount: number) => {
    approveDeposit(id);
    toast.success(`₹${amount} approved for @${username}!`);
    setRefresh(r => r + 1);
  };

  const handleReject = (id: string, username: string) => {
    rejectDeposit(id);
    toast.error(`Deposit rejected for @${username}`);
    setRefresh(r => r + 1);
  };

  return (
    <div className="p-4 space-y-5 animate-slide-up">
      <h1 className="font-display font-bold text-xl tracking-wider text-neon-yellow">
        <IndianRupee className="w-5 h-5 inline mr-2" />
        DEPOSIT REQUESTS
      </h1>

      {/* Pending */}
      <div className="glass-card rounded-xl p-4 border border-yellow-500/30">
        <h2 className="font-display font-bold text-sm tracking-widest text-yellow-400 mb-3">
          ⏳ PENDING ({pending.length})
        </h2>
        {pending.length === 0 ? (
          <p className="text-muted-foreground text-sm text-center py-4">No pending requests</p>
        ) : (
          <div className="space-y-3">
            {pending.map(r => (
              <div key={r.id} className="bg-muted/20 rounded-lg p-4 border border-border/30">
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <p className="text-base font-bold text-foreground">@{r.username}</p>
                    <p className="text-lg font-bold text-primary">₹{r.amount}</p>
                  </div>
                  <span className="text-xs px-2 py-1 rounded-full bg-yellow-500/20 text-yellow-400 font-bold">Pending</span>
                </div>
                <p className="text-xs text-muted-foreground mb-1">UTR: <span className="font-mono text-foreground">{r.utrNumber}</span></p>
                <p className="text-xs text-muted-foreground mb-3">{new Date(r.createdAt).toLocaleString()}</p>
                <div className="flex gap-2">
                  <button
                    onClick={() => handleApprove(r.id, r.username, r.amount)}
                    className="flex-1 flex items-center justify-center gap-1 bg-green-600 text-white font-display font-bold text-sm tracking-wider py-2.5 rounded-lg hover:bg-green-500 transition-all"
                  >
                    <CheckCircle className="w-4 h-4" /> APPROVE
                  </button>
                  <button
                    onClick={() => handleReject(r.id, r.username)}
                    className="flex-1 flex items-center justify-center gap-1 bg-destructive text-destructive-foreground font-display font-bold text-sm tracking-wider py-2.5 rounded-lg hover:brightness-110 transition-all"
                  >
                    <XCircle className="w-4 h-4" /> REJECT
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Processed */}
      {processed.length > 0 && (
        <div className="glass-card rounded-xl p-4">
          <h2 className="font-display font-bold text-sm tracking-widest text-muted-foreground mb-3">
            PROCESSED ({processed.length})
          </h2>
          <div className="space-y-2">
            {processed.slice(0, 20).map(r => (
              <div key={r.id} className="bg-muted/20 rounded-lg p-3 flex items-center justify-between">
                <div>
                  <p className="text-sm font-bold text-foreground">@{r.username} - ₹{r.amount}</p>
                  <p className="text-xs text-muted-foreground">UTR: {r.utrNumber}</p>
                </div>
                {r.status === "approved" ? (
                  <span className="text-xs px-2 py-0.5 rounded-full bg-green-500/20 text-green-400 font-bold">Approved</span>
                ) : (
                  <span className="text-xs px-2 py-0.5 rounded-full bg-destructive/20 text-destructive font-bold">Rejected</span>
                )}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
