import { getUsers, getOrders, getResellerApplications, getTransactions } from "@/lib/store";
import { Users, ShoppingCart, UserCheck, Wallet, Clock, Package } from "lucide-react";

export default function AdminDashboard() {
  const users = getUsers();
  const orders = getOrders();
  const apps = getResellerApplications();
  const txs = getTransactions();
  const pendingOrders = orders.filter(o => o.status === "pending");
  const pendingApps = apps.filter(a => a.status === "pending");
  const totalDeposits = txs.filter(t => t.type === "deposit" && t.status === "success").reduce((s, t) => s + t.amount, 0);
  const totalSales = txs.filter(t => t.type === "purchase" && t.status === "success").reduce((s, t) => s + t.amount, 0);

  const stats = [
    { icon: Users, label: "TOTAL USERS", value: users.length, color: "text-primary" },
    { icon: ShoppingCart, label: "PENDING ORDERS", value: pendingOrders.length, color: "text-neon-yellow" },
    { icon: UserCheck, label: "RESELLER APPS", value: pendingApps.length, color: "text-secondary" },
    { icon: Package, label: "TOTAL ORDERS", value: orders.length, color: "text-accent" },
    { icon: Wallet, label: "TOTAL DEPOSITS", value: `₹${totalDeposits.toFixed(0)}`, color: "text-neon-green" },
    { icon: Clock, label: "TOTAL SALES", value: `₹${totalSales.toFixed(0)}`, color: "text-neon-magenta" },
  ];

  return (
    <div className="p-4 space-y-5 animate-slide-up">
      <h1 className="font-display font-bold text-xl tracking-wider text-neon-yellow">OWNER DASHBOARD</h1>
      <div className="grid grid-cols-2 gap-3">
        {stats.map((s, i) => (
          <div key={i} className="glass-card rounded-xl p-4 border border-border/20">
            <s.icon className={`w-6 h-6 ${s.color} mb-2`} />
            <p className={`text-2xl font-bold ${s.color}`}>{s.value}</p>
            <p className="text-xs font-display tracking-widest text-muted-foreground mt-1">{s.label}</p>
          </div>
        ))}
      </div>

      {/* Recent pending orders */}
      {pendingOrders.length > 0 && (
        <div className="glass-card rounded-xl p-4 border border-neon-yellow/30">
          <h2 className="font-display font-bold tracking-wider text-neon-yellow mb-3">⚡ PENDING ORDERS ({pendingOrders.length})</h2>
          {pendingOrders.slice(0, 5).map(o => (
            <div key={o.id} className="bg-muted/20 rounded-lg p-3 mb-2">
              <div className="flex justify-between">
                <div>
                  <p className="text-sm font-semibold text-foreground">@{o.username}</p>
                  <p className="text-xs text-primary">{o.productName} - {o.duration} {o.type}</p>
                </div>
                <p className="text-sm font-bold text-foreground">₹{o.price}</p>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
