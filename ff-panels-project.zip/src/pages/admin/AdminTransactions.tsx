import { getTransactions } from "@/lib/store";
import { Clock } from "lucide-react";

export default function AdminTransactions() {
  const txs = getTransactions();

  return (
    <div className="p-4 space-y-5 animate-slide-up">
      <h1 className="font-display font-bold text-xl tracking-wider text-neon-yellow flex items-center gap-2">
        <Clock className="w-5 h-5" /> ALL TRANSACTIONS
      </h1>
      <p className="text-sm text-muted-foreground">{txs.length} total transactions</p>

      {txs.length === 0 ? (
        <div className="glass-card rounded-xl p-8 text-center">
          <p className="text-muted-foreground">No transactions yet</p>
        </div>
      ) : (
        <div className="space-y-2">
          {txs.map(tx => (
            <div key={tx.id} className="glass-card rounded-xl p-4 border border-border/20">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-muted-foreground font-mono">{tx.id}</p>
                  <p className="text-sm font-semibold text-foreground mt-1">{tx.description}</p>
                  <p className="text-xs text-muted-foreground mt-1">{new Date(tx.createdAt).toLocaleString()}</p>
                </div>
                <div className="text-right">
                  <p className={`text-lg font-bold ${tx.type === "deposit" || tx.type === "referral" ? "text-neon-green" : "text-secondary"}`}>
                    {tx.type === "deposit" || tx.type === "referral" ? "+" : "-"}₹{tx.amount.toFixed(2)}
                  </p>
                  <span className={`text-xs font-display tracking-wider px-2 py-0.5 rounded ${
                    tx.type === "deposit" ? "bg-primary/20 text-primary" :
                    tx.type === "purchase" ? "bg-secondary/20 text-secondary" :
                    tx.type === "reseller_fee" ? "bg-neon-yellow/20 text-neon-yellow" :
                    "bg-accent/20 text-accent"
                  }`}>
                    {tx.type.toUpperCase().replace("_", " ")}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
