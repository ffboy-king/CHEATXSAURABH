import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { adminLogin } from "@/lib/store";
import { Shield, Eye, EyeOff, Crown } from "lucide-react";
import { toast } from "sonner";

export default function AdminLoginPage() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [showPass, setShowPass] = useState(false);
  const navigate = useNavigate();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (adminLogin(username, password)) {
      toast.success("Owner access granted!");
      navigate("/admin/dashboard");
    } else {
      toast.error("Invalid owner credentials");
    }
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4 relative overflow-hidden">
      <div className="absolute w-32 h-32 rounded-full bg-neon-yellow/20 blur-3xl top-20 left-10 animate-float" />
      <div className="absolute w-40 h-40 rounded-full bg-secondary/15 blur-3xl bottom-20 right-10 animate-float" style={{ animationDelay: "1s" }} />

      <div className="w-full max-w-md glass-card rounded-2xl p-8 animate-slide-up relative z-10" style={{
        border: "1px solid hsl(50 100% 50% / 0.4)",
        boxShadow: "0 0 30px hsl(50 100% 50% / 0.2), 0 0 60px hsl(50 100% 50% / 0.1)"
      }}>
        <div className="flex flex-col items-center mb-8">
          <div className="w-20 h-20 rounded-full flex items-center justify-center mb-4" style={{
            border: "2px solid hsl(50 100% 50% / 0.5)",
            boxShadow: "0 0 20px hsl(50 100% 50% / 0.3)"
          }}>
            <Crown className="w-10 h-10 text-neon-yellow" />
          </div>
          <h1 className="font-display text-2xl font-bold tracking-wider">
            <span className="text-neon-yellow">OWNER</span>{" "}
            <span className="text-foreground">PANEL</span>
          </h1>
          <p className="text-muted-foreground text-sm tracking-widest font-display mt-1">ADMIN ACCESS ONLY</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          <input
            type="text"
            placeholder="OWNER USERNAME"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            className="w-full bg-input border border-border/50 rounded-lg px-4 py-3 text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-neon-yellow focus:ring-1 focus:ring-neon-yellow/50 font-medium tracking-wide"
            required
          />
          <div className="relative">
            <input
              type={showPass ? "text" : "password"}
              placeholder="OWNER PASSWORD"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full bg-input border border-border/50 rounded-lg px-4 py-3 text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-neon-yellow focus:ring-1 focus:ring-neon-yellow/50 font-medium tracking-wide pr-12"
              required
            />
            <button type="button" onClick={() => setShowPass(!showPass)} className="absolute right-4 top-1/2 -translate-y-1/2 text-muted-foreground">
              {showPass ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
            </button>
          </div>

          <button
            type="submit"
            className="w-full bg-neon-yellow text-background font-display font-bold tracking-widest py-3.5 rounded-lg hover:brightness-110 transition-all text-lg"
          >
            ACCESS PANEL
          </button>
        </form>

        <p className="text-center mt-6 text-muted-foreground text-xs">
          <a href="/login" className="neon-text-cyan hover:underline">← Back to User Login</a>
        </p>
      </div>
    </div>
  );
}
