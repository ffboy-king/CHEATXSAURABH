import { useState } from "react";
import { getResellerApplications, approveReseller, rejectReseller } from "@/lib/store";
import { UserCheck, CheckCircle, XCircle, Clock } from "lucide-react";
import { toast } from "sonner";

export default function AdminResellerApps() {
  const [, setRefresh] = useState(0);
  const apps = getResellerApplications();
  const pending = apps.filter(a => a.status === "pending");
  const others = apps.filter(a => a.status !== "pending");

  const handleApprove = (appId: string) => {
    approveReseller(appId);
    setRefresh(r => r + 1);
    toast.success("Reseller approved!");
  };

  const handleReject = (appId: string) => {
    rejectReseller(appId);
    setRefresh(r => r + 1);
    toast.success("Application rejected & ₹500 refunded");
  };

  return (
    <div className="p-4 space-y-5 animate-slide-up">
      <h1 className="font-display font-bold text-xl tracking-wider text-neon-yellow flex items-center gap-2">
        <UserCheck className="w-5 h-5" /> RESELLER APPLICATIONS
      </h1>

      {pending.length > 0 && (
        <div className="space-y-3">
          <h2 className="font-display font-bold tracking-wider text-neon-yellow text-sm">PENDING ({pending.length})</h2>
          {pending.map(app => (
            <div key={app.id} className="glass-card rounded-xl p-4 border border-neon-yellow/30">
              <div className="flex items-center gap-2 mb-2">
                <Clock className="w-4 h-4 text-neon-yellow" />
                <span className="font-semibold text-foreground">@{app.username}</span>
              </div>
              <p className="text-xs text-muted-foreground mb-1">{app.email}</p>
              <p className="text-xs text-muted-foreground mb-3">{new Date(app.createdAt).toLocaleString()}</p>
              <div className="flex gap-2">
                <button onClick={() => handleApprove(app.id)} className="flex-1 bg-neon-green/20 text-neon-green font-display font-bold tracking-wider py-2 rounded-lg text-sm flex items-center justify-center gap-1">
                  <CheckCircle className="w-4 h-4" /> APPROVE
                </button>
                <button onClick={() => handleReject(app.id)} className="flex-1 bg-destructive/20 text-destructive font-display font-bold tracking-wider py-2 rounded-lg text-sm flex items-center justify-center gap-1">
                  <XCircle className="w-4 h-4" /> REJECT
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {pending.length === 0 && (
        <div className="glass-card rounded-xl p-8 text-center">
          <p className="text-muted-foreground">No pending applications</p>
        </div>
      )}

      {others.length > 0 && (
        <div className="space-y-3 mt-6">
          <h2 className="font-display font-bold tracking-wider text-muted-foreground text-sm">HISTORY</h2>
          {others.map(app => (
            <div key={app.id} className={`glass-card rounded-xl p-4 border ${app.status === "approved" ? "border-neon-green/20" : "border-destructive/20"}`}>
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-semibold text-foreground">@{app.username}</p>
                  <p className="text-xs text-muted-foreground">{new Date(app.createdAt).toLocaleString()}</p>
                </div>
                <span className={`font-display font-bold tracking-wider text-xs ${app.status === "approved" ? "text-neon-green" : "text-destructive"}`}>
                  {app.status.toUpperCase()}
                </span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
