import { useState } from "react";
import { getProducts, updateProductPrices, toggleVariantStock } from "@/lib/store";
import { Package, Edit, Save } from "lucide-react";
import { toast } from "sonner";

export default function AdminProducts() {
  const [editingVariant, setEditingVariant] = useState<string | null>(null);
  const [editPrices, setEditPrices] = useState({ userPrice: 0, resellerPrice: 0 });
  const [, setRefresh] = useState(0);

  const products = getProducts();

  const startEdit = (variantId: string, userPrice: number, resellerPrice: number) => {
    setEditingVariant(variantId);
    setEditPrices({ userPrice, resellerPrice });
  };

  const saveEdit = (productId: string, variantId: string) => {
    updateProductPrices(productId, variantId, editPrices.userPrice, editPrices.resellerPrice);
    setEditingVariant(null);
    setRefresh(r => r + 1);
    toast.success("Prices updated!");
  };

  const handleToggleStock = (productId: string, variantId: string) => {
    toggleVariantStock(productId, variantId);
    setRefresh(r => r + 1);
    toast.success("Stock status toggled!");
  };

  return (
    <div className="p-4 space-y-5 animate-slide-up">
      <h1 className="font-display font-bold text-xl tracking-wider text-neon-yellow flex items-center gap-2">
        <Package className="w-5 h-5" /> PRODUCT & PRICE CONTROL
      </h1>

      {products.map(product => (
        <div key={product.id} className="glass-card rounded-xl overflow-hidden border border-border/20">
          <div className="bg-gradient-to-r from-neon-yellow/10 to-accent/10 p-4">
            <h2 className="font-display font-bold tracking-wider text-foreground">{product.name}</h2>
            <p className="text-xs text-muted-foreground">{product.features.join(" • ")}</p>
          </div>
          <div className="p-3 space-y-2">
            {product.variants.map(v => (
              <div key={v.id} className="bg-muted/20 rounded-lg p-3">
                <div className="flex items-center justify-between mb-1">
                  <div>
                    <p className="text-sm font-semibold text-foreground">{v.duration} {v.type}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => handleToggleStock(product.id, v.id)}
                      className={`text-xs font-display tracking-wider px-2 py-1 rounded ${v.inStock ? "bg-neon-green/20 text-neon-green" : "bg-destructive/20 text-destructive"}`}
                    >
                      {v.inStock ? "IN STOCK" : "OUT"}
                    </button>
                  </div>
                </div>

                {editingVariant === v.id ? (
                  <div className="space-y-2 mt-2">
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="text-xs text-muted-foreground">User Price</label>
                        <input
                          type="number"
                          value={editPrices.userPrice}
                          onChange={(e) => setEditPrices(p => ({ ...p, userPrice: Number(e.target.value) }))}
                          className="w-full bg-input border border-border/30 rounded px-2 py-1 text-sm text-foreground"
                        />
                      </div>
                      <div>
                        <label className="text-xs text-muted-foreground">Reseller Price</label>
                        <input
                          type="number"
                          value={editPrices.resellerPrice}
                          onChange={(e) => setEditPrices(p => ({ ...p, resellerPrice: Number(e.target.value) }))}
                          className="w-full bg-input border border-border/30 rounded px-2 py-1 text-sm text-foreground"
                        />
                      </div>
                    </div>
                    <button
                      onClick={() => saveEdit(product.id, v.id)}
                      className="w-full bg-neon-yellow/20 text-neon-yellow font-display font-bold tracking-wider py-2 rounded text-sm flex items-center justify-center gap-1"
                    >
                      <Save className="w-4 h-4" /> SAVE
                    </button>
                  </div>
                ) : (
                  <div className="flex items-center justify-between mt-1">
                    <div className="flex gap-4">
                      <span className="text-xs text-primary">User: ₹{v.userPrice}</span>
                      <span className="text-xs text-secondary">Reseller: ₹{v.resellerPrice}</span>
                    </div>
                    <button
                      onClick={() => startEdit(v.id, v.userPrice, v.resellerPrice)}
                      className="text-muted-foreground hover:text-neon-yellow"
                    >
                      <Edit className="w-4 h-4" />
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}
