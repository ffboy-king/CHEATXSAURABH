import { useState } from "react";
import { Outlet, Navigate, useNavigate, useLocation } from "react-router-dom";
import { isAdminLoggedIn, adminLogout } from "@/lib/store";
import { Crown, LayoutDashboard, Users, ShoppingCart, Package, UserCheck, Clock, LogOut, Menu, X, IndianRupee } from "lucide-react";

const adminMenu = [
  { icon: LayoutDashboard, label: "Dashboard", path: "/admin/dashboard" },
  { icon: IndianRupee, label: "Deposits", path: "/admin/deposits" },
  { icon: ShoppingCart, label: "Orders", path: "/admin/orders" },
  { icon: UserCheck, label: "Reseller Apps", path: "/admin/reseller-apps" },
  { icon: Users, label: "Users", path: "/admin/users" },
  { icon: Package, label: "Products", path: "/admin/products" },
  { icon: Clock, label: "Transactions", path: "/admin/transactions" },
];

export default function AdminLayout() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();

  if (!isAdminLoggedIn()) return <Navigate to="/admin" replace />;

  const handleLogout = () => {
    adminLogout();
    navigate("/admin");
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Overlay */}
      {sidebarOpen && <div className="fixed inset-0 bg-background/60 backdrop-blur-sm z-40" onClick={() => setSidebarOpen(false)} />}

      {/* Sidebar */}
      <div className={`fixed top-0 left-0 h-full w-72 bg-sidebar z-50 transform transition-transform duration-300 ${sidebarOpen ? "translate-x-0" : "-translate-x-full"} border-r border-neon-yellow/20`}>
        <div className="p-5">
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-3">
              <Crown className="w-6 h-6 text-neon-yellow" />
              <span className="font-display text-lg font-bold tracking-wider text-neon-yellow">OWNER PANEL</span>
            </div>
            <button onClick={() => setSidebarOpen(false)} className="text-muted-foreground"><X className="w-5 h-5" /></button>
          </div>
          <nav className="space-y-1">
            {adminMenu.map((item) => {
              const active = location.pathname === item.path;
              return (
                <button
                  key={item.path}
                  onClick={() => { navigate(item.path); setSidebarOpen(false); }}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg text-base font-medium transition-all ${
                    active ? "bg-neon-yellow/15 text-neon-yellow" : "text-sidebar-foreground hover:bg-sidebar-accent"
                  }`}
                >
                  <item.icon className="w-5 h-5" />
                  {item.label}
                </button>
              );
            })}
          </nav>
          <div className="mt-6 pt-4 border-t border-sidebar-border">
            <button onClick={handleLogout} className="w-full flex items-center gap-3 px-4 py-3 rounded-lg text-base font-medium text-destructive hover:bg-destructive/10">
              <LogOut className="w-5 h-5" /> Logout
            </button>
          </div>
        </div>
      </div>

      {/* Top bar */}
      <header className="sticky top-0 z-30 glass-card border-b border-neon-yellow/20">
        <div className="flex items-center justify-between px-4 py-3">
          <button onClick={() => setSidebarOpen(true)} className="text-foreground hover:text-neon-yellow">
            <Menu className="w-6 h-6" />
          </button>
          <div className="flex items-center gap-2">
            <Crown className="w-5 h-5 text-neon-yellow" />
            <span className="font-display text-sm font-bold tracking-wider text-neon-yellow">OWNER</span>
          </div>
        </div>
      </header>

      <main className="pb-20">
        <Outlet />
      </main>
    </div>
  );
}
