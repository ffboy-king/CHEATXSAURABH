import { useState } from "react";
import { getUsers, adminAddUserBalance } from "@/lib/store";
import { Users, Wallet, Plus } from "lucide-react";
import { toast } from "sonner";

export default function AdminUsers() {
  const [balanceInputs, setBalanceInputs] = useState<Record<string, string>>({});
  const [, setRefresh] = useState(0);

  const users = getUsers();

  const handleAddBalance = (userId: string) => {
    const amount = parseFloat(balanceInputs[userId] || "0");
    if (!amount || amount <= 0) { toast.error("Enter valid amount"); return; }
    adminAddUserBalance(userId, amount);
    setBalanceInputs(prev => ({ ...prev, [userId]: "" }));
    setRefresh(r => r + 1);
    toast.success(`₹${amount} added!`);
  };

  return (
    <div className="p-4 space-y-5 animate-slide-up">
      <h1 className="font-display font-bold text-xl tracking-wider text-neon-yellow flex items-center gap-2">
        <Users className="w-5 h-5" /> USER MANAGEMENT
      </h1>
      <p className="text-sm text-muted-foreground">{users.length} registered users</p>

      {users.length === 0 ? (
        <div className="glass-card rounded-xl p-8 text-center">
          <p className="text-muted-foreground">No users registered yet</p>
        </div>
      ) : (
        <div className="space-y-3">
          {users.map(u => (
            <div key={u.id} className="glass-card rounded-xl p-4 border border-border/20">
              <div className="flex items-start justify-between mb-2">
                <div>
                  <p className="font-semibold text-foreground">@{u.username}</p>
                  <p className="text-xs text-muted-foreground">{u.email}</p>
                  <span className={`text-xs font-display tracking-wider font-bold ${u.role === "reseller" ? "text-secondary" : "text-primary"}`}>
                    {u.role.toUpperCase()}
                  </span>
                </div>
                <div className="text-right">
                  <p className="text-lg font-bold text-foreground">₹{u.balance.toFixed(2)}</p>
                  <p className="text-xs text-muted-foreground">{new Date(u.createdAt).toLocaleDateString()}</p>
                </div>
              </div>

              {/* Add balance */}
              <div className="flex gap-2 mt-3">
                <input
                  type="number"
                  placeholder="Amount"
                  value={balanceInputs[u.id] || ""}
                  onChange={(e) => setBalanceInputs(prev => ({ ...prev, [u.id]: e.target.value }))}
                  className="flex-1 bg-input border border-border/30 rounded-lg px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-neon-yellow"
                />
                <button
                  onClick={() => handleAddBalance(u.id)}
                  className="bg-neon-green/20 text-neon-green px-4 py-2 rounded-lg font-display font-bold tracking-wider text-sm flex items-center gap-1"
                >
                  <Plus className="w-4 h-4" /> ADD
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
