import { useState } from "react";
import { getOrders, deliverOrder, cancelOrder } from "@/lib/store";
import { ShoppingCart, Send, XCircle, CheckCircle, Clock } from "lucide-react";
import { toast } from "sonner";

export default function AdminOrders() {
  const [filter, setFilter] = useState<"all" | "pending" | "delivered" | "cancelled">("pending");
  const [keyInputs, setKeyInputs] = useState<Record<string, string>>({});
  const [, setRefresh] = useState(0);

  const orders = getOrders();
  const filtered = filter === "all" ? orders : orders.filter(o => o.status === filter);

  const handleDeliver = (orderId: string) => {
    const key = keyInputs[orderId];
    if (!key || key.trim() === "") {
      toast.error("Enter a key code before delivering!");
      return;
    }
    deliverOrder(orderId, key.trim());
    setKeyInputs(prev => ({ ...prev, [orderId]: "" }));
    setRefresh(r => r + 1);
    toast.success(`Order ${orderId} delivered with key: ${key.trim()}`);
  };

  const handleCancel = (orderId: string) => {
    cancelOrder(orderId);
    setRefresh(r => r + 1);
    toast.success(`Order ${orderId} cancelled & refunded`);
  };

  return (
    <div className="p-4 space-y-5 animate-slide-up">
      <h1 className="font-display font-bold text-xl tracking-wider text-neon-yellow flex items-center gap-2">
        <ShoppingCart className="w-5 h-5" /> ORDER MANAGEMENT
      </h1>

      {/* Filter tabs */}
      <div className="grid grid-cols-4 gap-2">
        {(["pending", "delivered", "cancelled", "all"] as const).map(f => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`py-2 rounded-lg font-display font-bold tracking-wider text-xs transition-all ${
              filter === f ? "bg-neon-yellow/20 text-neon-yellow border border-neon-yellow/30" : "glass-card text-muted-foreground"
            }`}
          >
            {f.toUpperCase()}
          </button>
        ))}
      </div>

      <p className="text-sm text-muted-foreground">{filtered.length} orders</p>

      {filtered.length === 0 ? (
        <div className="glass-card rounded-xl p-8 text-center">
          <p className="text-muted-foreground">No {filter} orders</p>
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map((o) => (
            <div key={o.id} className={`glass-card rounded-xl p-4 border ${
              o.status === "pending" ? "border-neon-yellow/30" : o.status === "delivered" ? "border-neon-green/30" : "border-destructive/30"
            }`}>
              <div className="flex items-start justify-between mb-2">
                <div>
                  <div className="flex items-center gap-2">
                    {o.status === "pending" && <Clock className="w-4 h-4 text-neon-yellow" />}
                    {o.status === "delivered" && <CheckCircle className="w-4 h-4 text-neon-green" />}
                    {o.status === "cancelled" && <XCircle className="w-4 h-4 text-destructive" />}
                    <span className="font-mono text-xs text-muted-foreground">{o.id}</span>
                  </div>
                  <p className="font-semibold text-foreground mt-1">@{o.username}</p>
                  <p className="text-sm text-primary">{o.productName}</p>
                  <p className="text-xs text-muted-foreground">{o.duration} {o.type}</p>
                </div>
                <div className="text-right">
                  <p className="text-lg font-bold text-foreground">₹{o.price}</p>
                  <p className="text-xs text-muted-foreground">{new Date(o.createdAt).toLocaleString()}</p>
                </div>
              </div>

              {o.status === "pending" && (
                <div className="mt-3 space-y-2">
                  <input
                    type="text"
                    placeholder="Enter key code to deliver..."
                    value={keyInputs[o.id] || ""}
                    onChange={(e) => setKeyInputs(prev => ({ ...prev, [o.id]: e.target.value }))}
                    className="w-full bg-input border border-border/50 rounded-lg px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-neon-yellow"
                  />
                  <div className="flex gap-2">
                    <button
                      onClick={() => handleDeliver(o.id)}
                      className="flex-1 bg-neon-green/20 text-neon-green font-display font-bold tracking-wider py-2 rounded-lg text-sm flex items-center justify-center gap-1 hover:bg-neon-green/30"
                    >
                      <Send className="w-4 h-4" /> DELIVER KEY
                    </button>
                    <button
                      onClick={() => handleCancel(o.id)}
                      className="flex-1 bg-destructive/20 text-destructive font-display font-bold tracking-wider py-2 rounded-lg text-sm flex items-center justify-center gap-1 hover:bg-destructive/30"
                    >
                      <XCircle className="w-4 h-4" /> CANCEL
                    </button>
                  </div>
                </div>
              )}

              {o.status === "delivered" && o.keyCode && (
                <div className="mt-2 bg-neon-green/10 rounded-lg p-2 text-center">
                  <p className="text-xs text-muted-foreground">Delivered Key:</p>
                  <p className="font-mono font-bold text-neon-green">{o.keyCode}</p>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
