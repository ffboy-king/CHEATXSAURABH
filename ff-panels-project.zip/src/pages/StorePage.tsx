import { useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { getProducts, Product, updateUserBalance, addTransaction, createOrder } from "@/lib/store";
import { ShoppingCart, Zap, ChevronDown, ChevronUp } from "lucide-react";
import { toast } from "sonner";

function ProductCard({ product }: { product: Product }) {
  const { user, refreshUser } = useAuth();
  const [expanded, setExpanded] = useState(false);
  if (!user) return null;

  const isReseller = user.role === "reseller";

  const handleBuy = (variant: typeof product.variants[0]) => {
    const price = isReseller ? variant.resellerPrice : variant.userPrice;
    if (user.balance < price) {
      toast.error("Insufficient balance! Please deposit first.");
      return;
    }
    if (!variant.inStock) {
      toast.error("This item is out of stock!");
      return;
    }

    // Deduct balance
    updateUserBalance(user.id, -price);

    // Create order (pending - owner will deliver key manually)
    createOrder({
      userId: user.id,
      username: user.username,
      productName: product.name,
      variantId: variant.id,
      duration: variant.duration,
      type: variant.type,
      price,
    });

    addTransaction({
      userId: user.id,
      type: "purchase",
      amount: price,
      status: "success",
      description: `${product.name} - ${variant.duration} ${variant.type}`,
    });

    refreshUser();
    toast.success("Order placed! Owner will deliver your key soon. 🔑", { duration: 5000 });
  };

  return (
    <div className="glass-card rounded-2xl overflow-hidden neon-border-cyan animate-slide-up">
      <div className="bg-gradient-to-r from-primary/10 to-accent/10 p-5">
        <h3 className="font-display font-bold text-lg text-foreground text-center">{product.name}</h3>
        <div className="mt-3 space-y-1.5">
          {product.features.map((f, i) => (
            <div key={i} className="flex items-center gap-2 bg-muted/30 rounded-lg px-3 py-2">
              <Zap className="w-4 h-4 text-primary flex-shrink-0" />
              <span className="text-sm text-foreground">{f}</span>
            </div>
          ))}
        </div>
        <button onClick={() => setExpanded(!expanded)} className="flex items-center justify-center w-full mt-3 text-muted-foreground">
          {expanded ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
        </button>
      </div>

      {expanded && (
        <div className="p-4">
          <div className="bg-accent/10 rounded-lg py-2 px-4 mb-3 text-center">
            <span className="font-display font-bold text-sm tracking-wider text-accent">
              {isReseller ? "RESELLER RATES" : "PURCHASE KEY"}
            </span>
          </div>
          <div className="space-y-2.5">
            {product.variants.map((v) => {
              const price = isReseller ? v.resellerPrice : v.userPrice;
              return (
                <div key={v.id} className="flex items-center justify-between bg-muted/20 rounded-lg p-3 border border-border/20">
                  <div>
                    <p className="text-sm font-semibold text-primary">{v.duration} {v.type}</p>
                    <p className="text-lg font-bold text-foreground">₹{price.toFixed(2)}</p>
                  </div>
                  <button
                    onClick={() => handleBuy(v)}
                    disabled={!v.inStock}
                    className={`px-5 py-2 rounded-lg font-display font-bold tracking-wider text-sm transition-all ${
                      v.inStock
                        ? "bg-gradient-to-r from-accent to-primary text-primary-foreground hover:brightness-110"
                        : "bg-muted text-muted-foreground cursor-not-allowed"
                    }`}
                  >
                    {v.inStock ? "BUY" : "SOLD"}
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}

export default function StorePage() {
  const { user } = useAuth();
  if (!user) return null;

  const products = getProducts();
  const isReseller = user.role === "reseller";

  return (
    <div className="p-4 space-y-5 animate-slide-up">
      <h1 className="font-display font-bold text-lg tracking-wider neon-text-cyan">
        {">> "}MARKETPLACE / {isReseller ? "RESELLER STORE" : "USER STOCK"}
      </h1>
      <div className="glass-card rounded-lg p-3 text-center">
        <span className="text-sm text-muted-foreground font-display tracking-wider">
          {isReseller ? "RESELLER" : "USER"} BALANCE:{" "}
        </span>
        <span className="text-lg font-bold text-foreground font-display">₹{user.balance.toFixed(2)}</span>
      </div>
      <div className="space-y-5">
        {products.map((product) => (
          <ProductCard key={product.id} product={product} />
        ))}
      </div>
    </div>
  );
}
