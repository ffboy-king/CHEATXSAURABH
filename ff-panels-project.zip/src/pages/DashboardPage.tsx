import { useAuth } from "@/contexts/AuthContext";
import { TOP_SELLERS, getUserOrders, getTransactions, applyForReseller, RESELLER_FEE } from "@/lib/store";
import { Wallet, ShoppingCart, CalendarDays, Trophy, Search, Crown } from "lucide-react";
import { toast } from "sonner";

export default function DashboardPage() {
  const { user, refreshUser } = useAuth();
  if (!user) return null;

  const orders = getUserOrders(user.id);
  const todayOrders = orders.filter(o => new Date(o.createdAt).toDateString() === new Date().toDateString());

  const handleApplyReseller = () => {
    try {
      applyForReseller(user.id);
      refreshUser();
      toast.success("Application submitted! Owner will review it.");
    } catch (err: any) {
      toast.error(err.message);
    }
  };

  return (
    <div className="p-4 space-y-5 animate-slide-up">
      {/* Balance Card */}
      <div className="neon-border-magenta rounded-xl p-5 glass-card text-center">
        <p className="text-xs font-display tracking-widest text-muted-foreground">MY CURRENT BALANCE</p>
        <p className="text-4xl font-bold font-display neon-text-cyan mt-2">₹{user.balance.toFixed(2)}</p>
      </div>

      {/* Warning */}
      <div className="glass-card rounded-lg p-3 flex items-center gap-3 border border-accent/30">
        <span className="text-accent text-lg">🛡️</span>
        <p className="text-sm text-muted-foreground">Keep <span className="text-foreground font-semibold">2000+</span> balance for account safety.</p>
      </div>

      {/* Reseller Apply */}
      {user.role === "user" && user.resellerStatus === "none" && (
        <div className="glass-card rounded-xl p-5 neon-border-magenta">
          <div className="flex items-center gap-2 mb-2">
            <Crown className="w-5 h-5 text-secondary" />
            <h2 className="font-display font-bold tracking-wider text-foreground">BECOME A RESELLER</h2>
          </div>
          <p className="text-sm text-muted-foreground mb-3">Apply for reseller partnership and get lower prices on all products!</p>
          <p className="text-sm text-foreground mb-3">Fee: <span className="font-bold neon-text-magenta">₹{RESELLER_FEE}</span> (deducted from wallet)</p>
          <button
            onClick={handleApplyReseller}
            className="w-full bg-secondary text-secondary-foreground font-display font-bold tracking-widest py-3 rounded-lg hover:brightness-110 transition-all"
          >
            APPLY NOW - ₹{RESELLER_FEE}
          </button>
        </div>
      )}

      {user.resellerStatus === "pending" && (
        <div className="glass-card rounded-xl p-4 border border-neon-yellow/30 text-center">
          <p className="font-display font-bold tracking-wider text-neon-yellow">⏳ RESELLER APPLICATION PENDING</p>
          <p className="text-sm text-muted-foreground mt-1">Owner will review your application soon.</p>
        </div>
      )}

      {user.role === "reseller" && (
        <div className="glass-card rounded-xl p-4 neon-border-magenta text-center">
          <p className="font-display font-bold tracking-wider text-secondary">👑 RESELLER PARTNER</p>
          <p className="text-sm text-muted-foreground mt-1">You enjoy discounted reseller rates!</p>
        </div>
      )}

      {/* Stats */}
      <div className="grid grid-cols-2 gap-4">
        <div className="glass-card rounded-xl p-4 neon-border-purple">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-3xl font-bold text-foreground">{todayOrders.length}</p>
              <p className="text-xs font-display tracking-widest text-muted-foreground mt-1">TODAY ORDERS</p>
            </div>
            <ShoppingCart className="w-6 h-6 text-accent opacity-50" />
          </div>
        </div>
        <div className="glass-card rounded-xl p-4 neon-border-cyan">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-3xl font-bold text-foreground">{orders.length}</p>
              <p className="text-xs font-display tracking-widest text-muted-foreground mt-1">TOTAL ORDERS</p>
            </div>
            <CalendarDays className="w-6 h-6 text-primary opacity-50" />
          </div>
        </div>
      </div>

      {/* Top Sellers */}
      <div className="glass-card rounded-xl p-5 border border-neon-yellow/30" style={{ boxShadow: "0 0 20px hsl(50 100% 50% / 0.1)" }}>
        <div className="flex items-center gap-2 mb-4">
          <Trophy className="w-5 h-5 text-neon-yellow" />
          <h2 className="font-display font-bold tracking-wider text-foreground">5 TOP SELLERS</h2>
        </div>
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-border/30">
              <th className="text-left py-2 px-2 text-muted-foreground font-display tracking-wider text-xs">RANK</th>
              <th className="text-left py-2 px-2 text-muted-foreground font-display tracking-wider text-xs">USERNAME</th>
              <th className="text-right py-2 px-2 text-muted-foreground font-display tracking-wider text-xs">TYPE</th>
            </tr>
          </thead>
          <tbody>
            {TOP_SELLERS.map((s) => (
              <tr key={s.rank} className="border-b border-border/10">
                <td className="py-3 px-2 font-bold text-foreground">#{s.rank}</td>
                <td className="py-3 px-2 font-semibold text-primary">{s.username}</td>
                <td className="py-3 px-2 text-right">
                  <span className="bg-muted text-muted-foreground px-3 py-1 rounded text-xs font-display tracking-wider">{s.type}</span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
