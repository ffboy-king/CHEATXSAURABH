import { useAuth } from "@/contexts/AuthContext";
import { getUsers } from "@/lib/store";
import { Users, Copy, Gift } from "lucide-react";
import { toast } from "sonner";

export default function ReferralPage() {
  const { user } = useAuth();
  if (!user) return null;

  const allUsers = getUsers();
  const referrals = allUsers.filter(u => u.referredBy === user.referralCode);
  const referralLink = `${window.location.origin}/register?ref=${user.referralCode}`;

  const copyLink = () => {
    navigator.clipboard.writeText(referralLink);
    toast.success("Link copied!");
  };

  return (
    <div className="p-4 space-y-5 animate-slide-up">
      <h1 className="font-display font-bold text-lg tracking-wider neon-text-cyan flex items-center gap-2">
        <Gift className="w-5 h-5" /> AFFILIATE / REFERRAL SYSTEM
      </h1>

      {/* Earned */}
      <div className="glass-card rounded-xl p-5 neon-border-magenta text-center">
        <p className="text-xs font-display tracking-widest text-muted-foreground">EARNED REWARDS</p>
        <p className="text-3xl font-bold font-display text-foreground mt-2">₹0.00</p>
        <button className="mt-3 bg-primary text-primary-foreground font-display font-bold tracking-widest py-2 px-6 rounded-lg text-sm">
          CLAIM NOW
        </button>
      </div>

      {/* Invite Link */}
      <div className="glass-card rounded-xl p-5 neon-border-cyan">
        <p className="text-xs font-display tracking-widest text-muted-foreground mb-3">INVITE LINK</p>
        <div className="flex gap-2">
          <input
            type="text"
            value={referralLink}
            readOnly
            className="flex-1 bg-input border border-border/30 rounded-lg px-3 py-2 text-sm text-foreground truncate"
          />
          <button
            onClick={copyLink}
            className="bg-primary text-primary-foreground px-4 py-2 rounded-lg font-display font-bold tracking-wider text-sm flex items-center gap-1"
          >
            <Copy className="w-4 h-4" /> COPY
          </button>
        </div>
      </div>

      {/* Network */}
      <div className="glass-card rounded-xl p-5">
        <h2 className="font-display font-bold tracking-wider text-foreground mb-3">MY NETWORK</h2>
        {referrals.length === 0 ? (
          <p className="text-muted-foreground text-sm text-center py-4">No Network</p>
        ) : (
          <div className="space-y-2">
            {referrals.map((r) => (
              <div key={r.id} className="flex items-center justify-between bg-muted/20 rounded-lg p-3">
                <span className="text-sm font-semibold text-foreground">@{r.username}</span>
                <span className="text-xs text-muted-foreground">{r.role.toUpperCase()}</span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
