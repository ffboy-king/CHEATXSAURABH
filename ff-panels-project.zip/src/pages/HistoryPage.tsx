import { useAuth } from "@/contexts/AuthContext";
import { getTransactions } from "@/lib/store";
import { Clock, Search } from "lucide-react";
import { useState } from "react";

export default function HistoryPage() {
  const { user } = useAuth();
  const [search, setSearch] = useState("");
  if (!user) return null;

  const txs = getTransactions(user.id);
  const filtered = txs.filter(t =>
    t.description.toLowerCase().includes(search.toLowerCase()) ||
    t.id.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="p-4 space-y-5 animate-slide-up">
      <h1 className="font-display font-bold text-lg tracking-wider neon-text-cyan flex items-center gap-2">
        <Clock className="w-5 h-5" /> TRANSACTION HISTORY
      </h1>

      <div className="glass-card rounded-lg p-3 text-center">
        <span className="font-display tracking-widest text-sm text-muted-foreground">ALL ACTIVITIES</span>
      </div>

      <div className="relative">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <input
          type="text"
          placeholder="Search records..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-full bg-input border border-border/50 rounded-lg pl-10 pr-4 py-3 text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary"
        />
      </div>

      {filtered.length === 0 ? (
        <div className="glass-card rounded-xl p-8 text-center neon-border-cyan">
          <Clock className="w-12 h-12 text-muted-foreground mx-auto mb-3" />
          <p className="text-muted-foreground">NO DATA FOUND</p>
        </div>
      ) : (
        <div className="space-y-2">
          {filtered.map((tx) => (
            <div key={tx.id} className="glass-card rounded-xl p-4 border border-border/20">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-muted-foreground font-mono">{tx.id}</p>
                  <p className="text-sm font-semibold text-foreground mt-1">{tx.description}</p>
                  <p className="text-xs text-muted-foreground mt-1">{new Date(tx.createdAt).toLocaleString()}</p>
                </div>
                <div className="text-right">
                  <p className={`text-lg font-bold ${tx.type === "deposit" || tx.type === "referral" ? "text-neon-green" : "text-secondary"}`}>
                    {tx.type === "deposit" || tx.type === "referral" ? "+" : "-"}₹{tx.amount.toFixed(2)}
                  </p>
                  <span className={`text-xs font-display tracking-wider px-2 py-0.5 rounded ${
                    tx.type === "deposit" ? "bg-primary/20 text-primary" :
                    tx.type === "purchase" ? "bg-secondary/20 text-secondary" :
                    "bg-accent/20 text-accent"
                  }`}>
                    {tx.type.toUpperCase()}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
