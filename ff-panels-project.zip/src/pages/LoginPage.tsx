import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { Shield, Eye, EyeOff } from "lucide-react";
import { toast } from "sonner";

export default function LoginPage() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [showPass, setShowPass] = useState(false);
  const { login, user } = useAuth();
  const navigate = useNavigate();

  if (user) {
    navigate("/dashboard", { replace: true });
    return null;
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    try {
      login(username, password);
      toast.success("Login successful!");
      navigate("/dashboard");
    } catch (err: any) {
      toast.error(err.message);
    }
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4 relative overflow-hidden">
      {/* Floating orbs */}
      <div className="absolute w-32 h-32 rounded-full bg-primary/20 blur-3xl top-20 left-10 animate-float" />
      <div className="absolute w-40 h-40 rounded-full bg-neon-magenta/15 blur-3xl bottom-20 right-10 animate-float" style={{ animationDelay: "1s" }} />
      <div className="absolute w-24 h-24 rounded-full bg-accent/20 blur-3xl top-1/2 right-1/4 animate-float" style={{ animationDelay: "2s" }} />

      <div className="w-full max-w-md glass-card rounded-2xl p-8 neon-border-cyan animate-slide-up relative z-10">
        {/* Logo */}
        <div className="flex flex-col items-center mb-8">
          <div className="w-20 h-20 rounded-full neon-border-cyan flex items-center justify-center mb-4 animate-pulse-glow">
            <Shield className="w-10 h-10 text-primary" />
          </div>
          <h1 className="font-display text-2xl font-bold tracking-wider">
            <span className="neon-text-cyan">FF</span>{" "}
            <span className="text-foreground">PANELS</span>
          </h1>
          <p className="text-muted-foreground text-sm tracking-widest font-display mt-1">AUTHORIZE ACCESS</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          <div>
            <input
              type="text"
              placeholder="USER NAME"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full bg-input border border-border/50 rounded-lg px-4 py-3 text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary/50 font-medium tracking-wide"
              required
            />
          </div>
          <div className="relative">
            <input
              type={showPass ? "text" : "password"}
              placeholder="PASSWORD"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full bg-input border border-border/50 rounded-lg px-4 py-3 text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary/50 font-medium tracking-wide pr-12"
              required
            />
            <button type="button" onClick={() => setShowPass(!showPass)} className="absolute right-4 top-1/2 -translate-y-1/2 text-muted-foreground">
              {showPass ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
            </button>
          </div>

          <button
            type="submit"
            className="w-full bg-primary text-primary-foreground font-display font-bold tracking-widest py-3.5 rounded-lg hover:brightness-110 transition-all text-lg"
          >
            LOGIN NOW
          </button>
        </form>

        <p className="text-center mt-6 text-muted-foreground">
          New User?{" "}
          <Link to="/register" className="neon-text-cyan hover:underline font-semibold">Create Account</Link>
        </p>

        <p className="text-center mt-4 text-xs text-muted-foreground/60">© 2026 FF PANELS SYSTEM</p>
      </div>
    </div>
  );
}
