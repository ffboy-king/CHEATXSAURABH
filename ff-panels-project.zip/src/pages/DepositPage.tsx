import { useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { createDepositRequest, getDepositRequests, getTransactions } from "@/lib/store";
import { Wallet, Zap, Copy, CheckCircle, IndianRupee, Clock, XCircle } from "lucide-react";
import { toast } from "sonner";
import upiQrImage from "@/assets/upi-qr.png";

const UPI_ID = "fflovergaming22-5@okicici";
const QUICK_AMOUNTS = [50, 100, 200, 500, 1000, 2000];

export default function DepositPage() {
  const { user, refreshUser } = useAuth();
  const [amount, setAmount] = useState("");
  const [utrNumber, setUtrNumber] = useState("");
  const [step, setStep] = useState<"enter" | "pay" | "verify">("enter");
  const [submitted, setSubmitted] = useState(false);

  if (!user) return null;

  const todayDeposits = (() => {
    const txs = getTransactions(user.id);
    return txs
      .filter((t) => t.type === "deposit" && t.status === "success" && new Date(t.createdAt).toDateString() === new Date().toDateString())
      .reduce((sum, t) => sum + t.amount, 0);
  })();

  const myRequests = getDepositRequests().filter(r => r.userId === user.id).slice(0, 10);

  const copyUPI = () => {
    navigator.clipboard.writeText(UPI_ID);
    toast.success("UPI ID copied!");
  };

  const handleProceedToPay = () => {
    const amt = parseFloat(amount);
    if (!amt || amt < 10) {
      toast.error("Minimum deposit is ₹10");
      return;
    }
    setStep("pay");
  };

  const handleConfirmPayment = () => {
    if (!utrNumber || utrNumber.length < 10 || utrNumber.length > 14) {
      toast.error("Valid 12-digit UTR number daalo");
      return;
    }
    const amt = parseFloat(amount);
    createDepositRequest(user.id, user.username, amt, utrNumber);
    setSubmitted(true);
    setAmount("");
    setUtrNumber("");
    setStep("enter");
    toast.success("Deposit request submitted! Owner approve karega tab balance add hoga.");
    setTimeout(() => setSubmitted(false), 3000);
  };

  const statusBadge = (status: string) => {
    if (status === "approved") return <span className="text-xs px-2 py-0.5 rounded-full bg-green-500/20 text-green-400 font-bold">✓ Approved</span>;
    if (status === "rejected") return <span className="text-xs px-2 py-0.5 rounded-full bg-destructive/20 text-destructive font-bold">✗ Rejected</span>;
    return <span className="text-xs px-2 py-0.5 rounded-full bg-yellow-500/20 text-yellow-400 font-bold">⏳ Pending</span>;
  };

  return (
    <div className="p-4 space-y-5 animate-slide-up">
      {/* Balance Cards */}
      <div className="grid grid-cols-2 gap-4">
        <div className="glass-card rounded-xl p-4 neon-border-purple text-center">
          <p className="text-xs font-display tracking-widest text-muted-foreground">CURRENT BALANCE</p>
          <p className="text-2xl font-bold font-display text-foreground mt-1">₹{user.balance.toFixed(2)}</p>
        </div>
        <div className="glass-card rounded-xl p-4 neon-border-cyan text-center">
          <p className="text-xs font-display tracking-widest text-muted-foreground">TODAY DEPOSIT</p>
          <p className="text-2xl font-bold font-display text-foreground mt-1">₹{todayDeposits.toFixed(2)}</p>
        </div>
      </div>

      {step === "enter" && (
        <div className="glass-card rounded-2xl p-6 neon-border-cyan">
          <div className="flex flex-col items-center mb-5">
            <div className="w-14 h-14 rounded-full bg-accent/20 flex items-center justify-center mb-3">
              <IndianRupee className="w-7 h-7 text-accent" />
            </div>
            <h2 className="font-display font-bold text-xl text-foreground">UPI Deposit</h2>
            <p className="text-muted-foreground text-sm mt-1">Pay via UPI → Owner approve karega → Balance add hoga</p>
          </div>

          <div className="space-y-4">
            <div>
              <label className="text-xs font-display tracking-widest text-muted-foreground block mb-2">AMOUNT (₹)</label>
              <div className="relative">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-primary font-bold">₹</span>
                <input
                  type="number"
                  placeholder="Enter amount (min ₹10)"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  className="w-full bg-input border border-border/50 rounded-lg pl-10 pr-4 py-3 text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary/50"
                />
              </div>
            </div>

            <div className="grid grid-cols-3 gap-2">
              {QUICK_AMOUNTS.map((qa) => (
                <button
                  key={qa}
                  onClick={() => setAmount(qa.toString())}
                  className={`py-2 rounded-lg text-sm font-display font-bold tracking-wider transition-all ${
                    amount === qa.toString()
                      ? "bg-primary text-primary-foreground"
                      : "glass-card text-muted-foreground hover:text-foreground"
                  }`}
                >
                  ₹{qa}
                </button>
              ))}
            </div>

            <button
              onClick={handleProceedToPay}
              className="w-full bg-accent text-accent-foreground font-display font-bold tracking-widest py-3.5 rounded-lg hover:brightness-110 transition-all text-lg flex items-center justify-center gap-2"
            >
              <Zap className="w-5 h-5" />
              PROCEED TO PAY
            </button>
          </div>
        </div>
      )}

      {step === "pay" && (
        <div className="glass-card rounded-2xl p-6 neon-border-cyan">
          <div className="flex flex-col items-center mb-4">
            <h2 className="font-display font-bold text-xl text-foreground mb-1">Pay ₹{parseFloat(amount).toFixed(2)}</h2>
            <p className="text-muted-foreground text-sm">Scan QR or pay to UPI ID below</p>
          </div>

          <div className="bg-white rounded-xl p-4 mx-auto max-w-[260px] mb-4">
            <img src={upiQrImage} alt="UPI QR Code" className="w-full h-auto rounded-lg" />
          </div>

          <div className="flex items-center justify-between glass-card rounded-lg p-3 mb-4">
            <div>
              <p className="text-xs text-muted-foreground font-display tracking-widest">UPI ID</p>
              <p className="text-sm font-bold text-foreground font-mono">{UPI_ID}</p>
            </div>
            <button onClick={copyUPI} className="p-2 rounded-lg bg-primary/20 text-primary hover:bg-primary/30 transition-all">
              <Copy className="w-4 h-4" />
            </button>
          </div>

          <div className="text-center mb-4">
            <p className="text-xs text-muted-foreground">Payment karke neeche UTR number daalo</p>
          </div>

          <div className="space-y-3">
            <div>
              <label className="text-xs font-display tracking-widest text-muted-foreground block mb-2">UTR / TRANSACTION ID</label>
              <input
                type="text"
                placeholder="Enter 12-digit UTR number"
                value={utrNumber}
                onChange={(e) => setUtrNumber(e.target.value)}
                className="w-full bg-input border border-border/50 rounded-lg px-4 py-3 text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary/50"
              />
            </div>

            <button
              onClick={handleConfirmPayment}
              className="w-full bg-accent text-accent-foreground font-display font-bold tracking-widest py-3.5 rounded-lg hover:brightness-110 transition-all text-lg flex items-center justify-center gap-2"
            >
              <CheckCircle className="w-5 h-5" />
              SUBMIT FOR APPROVAL
            </button>

            <button
              onClick={() => setStep("enter")}
              className="w-full text-muted-foreground font-display text-sm tracking-wider py-2"
            >
              ← BACK
            </button>
          </div>
        </div>
      )}

      {/* My Deposit Requests */}
      {myRequests.length > 0 && (
        <div className="glass-card rounded-2xl p-5">
          <h3 className="font-display font-bold text-sm tracking-widest text-muted-foreground mb-3">MY DEPOSIT REQUESTS</h3>
          <div className="space-y-2">
            {myRequests.map(r => (
              <div key={r.id} className="bg-muted/20 rounded-lg p-3 flex items-center justify-between">
                <div>
                  <p className="text-sm font-bold text-foreground">₹{r.amount}</p>
                  <p className="text-xs text-muted-foreground">UTR: {r.utrNumber}</p>
                  <p className="text-xs text-muted-foreground">{new Date(r.createdAt).toLocaleString()}</p>
                </div>
                {statusBadge(r.status)}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
