import React, { createContext, useContext, useState, useCallback, ReactNode } from "react";
import { User, getCurrentUser, setCurrentUser, loginUser as storeLogin, registerUser as storeRegister, logoutUser as storeLogout, refreshCurrentUserFromStore } from "@/lib/store";

interface AuthContextType {
  user: User | null;
  login: (username: string, password: string) => User;
  register: (username: string, email: string, password: string) => User;
  logout: () => void;
  refreshUser: () => void;
}

const AuthContext = createContext<AuthContextType | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(getCurrentUser);

  const login = useCallback((username: string, password: string) => {
    const u = storeLogin(username, password);
    setUser(u);
    return u;
  }, []);

  const register = useCallback((username: string, email: string, password: string) => {
    const u = storeRegister(username, email, password);
    setCurrentUser(u);
    setUser(u);
    return u;
  }, []);

  const logout = useCallback(() => {
    storeLogout();
    setUser(null);
  }, []);

  const refreshUser = useCallback(() => {
    const updated = refreshCurrentUserFromStore();
    setUser(updated);
  }, []);

  return (
    <AuthContext.Provider value={{ user, login, register, logout, refreshUser }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}
